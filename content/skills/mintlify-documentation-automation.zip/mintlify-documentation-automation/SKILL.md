---
name: mintlify-documentation-automation
description: Automate beautiful, searchable documentation creation with Mintlify, AI-powered content generation from code, and interactive MDX components.
---

# Mintlify AI Documentation Automation Skill

## What This Skill Enables

Claude can generate comprehensive, production-ready documentation using Mintlify - the modern documentation platform that has become the standard for developer-facing docs in 2025. This skill enables automatic API reference generation from code, interactive MDX components, multi-version documentation, and AI-powered content creation from JSDoc/TypeScript types.

## Prerequisites

**Required:**
- Node.js 18+
- Existing codebase with functions/APIs to document
- Basic understanding of Markdown

**What Claude handles automatically:**
- Generating MDX documentation from TypeScript/JSDoc
- Creating mint.json configuration with navigation
- Building API reference pages from OpenAPI specs
- Setting up interactive code examples
- Configuring search, analytics, and versioning
- Creating custom MDX components

## How to Use This Skill

### API Documentation from TypeScript

**Prompt:** "Generate Mintlify documentation from my TypeScript API client at src/api/users.ts. Include all JSDoc comments, parameter types, return types, and code examples."

Claude will:
1. Parse TypeScript file and extract exported functions
2. Read JSDoc comments for descriptions
3. Generate MDX files for each API endpoint
4. Create proper Mintlify components (ParamField, ResponseField)
5. Add code examples in multiple languages
6. Generate response examples with proper formatting
7. Update mint.json navigation

### OpenAPI to Interactive Documentation

**Prompt:** "Convert my OpenAPI 3.0 spec (openapi.yaml) into Mintlify documentation with interactive API playground and authentication examples."

Claude will create:
1. API reference section in mint.json
2. MDX file for each endpoint with proper structure
3. Request/response examples using CodeGroup
4. Authentication documentation with examples
5. Error code reference table
6. API playground integration
7. SDK code examples (TypeScript, Python, cURL)

### Complete Documentation Site Setup

**Prompt:** "Set up a complete Mintlify documentation site for my SaaS product with: Introduction, Quickstart, API Reference, Guides, Changelog. Include dark mode, search, and analytics."

Claude will generate:
1. Directory structure with organized MDX files
2. mint.json with proper navigation tabs
3. Introduction page with hero and feature cards
4. Quickstart with step-by-step instructions
5. API reference structure
6. Guide templates
7. Changelog format
8. Dark mode configuration
9. Search and analytics integration

### Interactive Component Library Documentation

**Prompt:** "Document my React component library with interactive examples, prop tables, and usage guidelines. Components are in src/components/ui."

Claude will create:
1. Component documentation pages with descriptions
2. PropTable components with TypeScript types
3. Interactive code playgrounds
4. Usage examples with best practices
5. Accessibility guidelines per component
6. Storybook integration links
7. Installation and import instructions

## Tips for Best Results

1. **Rich JSDoc Comments**: Ensure your code has comprehensive JSDoc comments with @param, @returns, @throws, and @example tags for best auto-generation results.

2. **OpenAPI First**: If you have an OpenAPI spec, use that as the source of truth. Mintlify's OpenAPI integration is more reliable than manual documentation.

3. **Code Examples**: Request examples in multiple languages (TypeScript, JavaScript, Python, cURL) to maximize usefulness for different audiences.

4. **Interactive Elements**: Ask for Mintlify-specific components (Accordion, Card, Tabs, CodeGroup) to make docs more engaging than plain Markdown.

5. **Version Management**: For libraries, request versioned documentation setup from the start to avoid migration pain later.

6. **Search Optimization**: Include descriptive meta titles and descriptions in frontmatter for better search discoverability.

## Common Workflows

### Complete API Documentation
```
"Generate full Mintlify API documentation:
1. Parse src/api/*.ts files for all exported functions
2. Create API reference pages with proper Mintlify components
3. Include TypeScript type definitions
4. Add code examples in TypeScript, JavaScript, Python, and cURL
5. Document all error codes and responses
6. Set up authentication guide with OAuth 2.0 flow
7. Configure API playground with authentication
8. Add rate limiting documentation"
```

### Component Library Docs
```
"Build Mintlify docs for React component library:
1. Document all components in src/components/ui
2. Extract prop types from TypeScript interfaces
3. Create PropTable for each component
4. Add usage examples with CodeGroup
5. Include accessibility guidelines (ARIA, keyboard)
6. Link to Storybook for interactive demos
7. Add installation guide with package manager options
8. Create theming and customization guide"
```

### SDK Documentation with Examples
```
"Generate SDK documentation from TypeScript client:
1. Document all SDK methods with parameters and returns
2. Create quickstart with installation and auth setup
3. Add comprehensive code examples for each method
4. Include error handling patterns
5. Document webhook integration
6. Add retry and timeout configuration
7. Create migration guide from v1 to v2
8. Set up changelog with semantic versioning"
```

### Multi-Version Documentation
```
"Set up versioned Mintlify docs for API v1 and v2:
1. Create separate documentation for each version
2. Configure version switcher in mint.json
3. Highlight breaking changes between versions
4. Provide migration guide from v1 to v2
5. Maintain v1 docs in archive with deprecation notice
6. Set up URL structure: /v1/... and /v2/...
7. Add version-specific examples"
```

## Troubleshooting

**Issue:** Mintlify build fails with "Invalid frontmatter"
**Solution:** Ensure all MDX files have valid YAML frontmatter with required fields (title, description). Ask Claude to validate frontmatter syntax.

**Issue:** Navigation doesn't match folder structure
**Solution:** mint.json navigation must explicitly list all pages. Ask Claude to regenerate navigation section matching your actual MDX file structure.

**Issue:** Code examples aren't syntax highlighted correctly
**Solution:** Specify language in code fence (```typescript, not ```ts). Ask Claude to use full language names for better highlighting.

**Issue:** API Reference pages look inconsistent
**Solution:** Use Mintlify's built-in components (ParamField, ResponseField) instead of manual tables. Request Claude to refactor using proper components.

**Issue:** Search doesn't find relevant pages
**Solution:** Add descriptive `seoTitle` and `description` in frontmatter. Ask Claude to optimize metadata for search.

## Learn More

- [Mintlify Documentation](https://mintlify.com/docs)
- [Mintlify Components](https://mintlify.com/docs/components)
- [OpenAPI Integration](https://mintlify.com/docs/api-playground/openapi)
- [Custom Components](https://mintlify.com/docs/components/custom)
- [Versioning Guide](https://mintlify.com/docs/settings/versioning)


## Prerequisites

- Node.js 18+
- Mintlify CLI: npm install -g mintlify
- Codebase with JSDoc or TypeScript types

## Key Features

- Auto-generate docs from TypeScript/JSDoc
- OpenAPI to interactive API reference
- Interactive MDX components (Tabs, Accordion, CodeGroup)
- Multi-version documentation support
- Built-in search and analytics
- API playground with authentication

## Use Cases

- API reference documentation from code
- SDK and library documentation
- Product documentation with guides and tutorials
- Component library documentation

## Examples

### Example 1: API Reference Page from TypeScript

```mdx
---
title: 'Get User'
description: 'Retrieve a user by their unique identifier'
api: 'GET /api/users/{userId}'
---

# Get User

Retrieves a user by their unique identifier.

## Path Parameters

<ParamField path="userId" type="string" required>
  The user's unique identifier
</ParamField>

## Response

<ResponseField name="id" type="string" required>
  Unique user identifier
</ResponseField>

<ResponseField name="email" type="string" required>
  User's email address
</ResponseField>

<ResponseField name="name" type="string" required>
  Display name
</ResponseField>

<ResponseField name="role" type="'admin' | 'user' | 'guest'" required>
  User role determining access permissions
</ResponseField>

## Code Examples

<CodeGroup>

```typescript TypeScript SDK
import { getUser } from '@yourapp/sdk';

const user = await getUser('user_123');
console.log(user.name);
```

```javascript JavaScript
const response = await fetch('/api/users/user_123');
const user = await response.json();
```

```python Python
import requests

response = requests.get('https://api.yourapp.com/users/user_123')
user = response.json()
```

```bash cURL
curl https://api.yourapp.com/users/user_123 \\
  -H "Authorization: Bearer YOUR_TOKEN"
```

</CodeGroup>

## Response Example

<ResponseExample>

```json 200 Success
{
  "id": "user_123",
  "email": "user@example.com",
  "name": "John Doe",
  "role": "user",
  "createdAt": "2025-10-16T12:00:00Z"
}
```

```json 404 Not Found
{
  "error": "User not found",
  "code": "USER_NOT_FOUND"
}
```

</ResponseExample>

## Error Codes

<ResponseField name="404" type="NotFoundError">
  User with the specified ID doesn't exist
</ResponseField>

<ResponseField name="403" type="AuthorizationError">
  Caller lacks permission to access this user
</ResponseField>
```

### Example 2: Quickstart Guide with Steps

```mdx
---
title: 'Quickstart'
description: 'Get started in 5 minutes'
icon: 'rocket'
---

# Getting Started

This guide will help you integrate our SDK in under 5 minutes.

<Steps>

<Step title="Install the SDK">
  Install using your preferred package manager:

  <CodeGroup>

  ```bash npm
  npm install @yourapp/sdk
  ```

  ```bash pnpm
  pnpm add @yourapp/sdk
  ```

  ```bash yarn
  yarn add @yourapp/sdk
  ```

  </CodeGroup>
</Step>

<Step title="Configure Environment">
  Add your API credentials to `.env`:

  ```bash .env
  API_KEY=your-api-key
  API_URL=https://api.yourapp.com
  ```

  <Warning>
    Never commit your `.env` file to version control.
  </Warning>
</Step>

<Step title="Initialize the Client">
  Create a client instance:

  ```typescript lib/client.ts
  import { createClient } from '@yourapp/sdk';

  export const client = createClient({
    apiKey: process.env.API_KEY!,
    baseUrl: process.env.API_URL!,
  });
  ```
</Step>

<Step title="Make Your First Request">
  Use the client in your application:

  ```typescript app/page.tsx
  import { client } from '@/lib/client';

  export default async function Page() {
    const users = await client.users.list();
    
    return (
      <div>
        {users.map(user => (
          <div key={user.id}>{user.name}</div>
        ))}
      </div>
    );
  }
  ```

  <Check>
    You're all set! Check out the API reference for more.
  </Check>
</Step>

</Steps>

## Next Steps

<CardGroup cols={2}>

<Card title="API Reference" icon="code" href="/api-reference">
  Explore the complete API documentation
</Card>

<Card title="Authentication" icon="shield" href="/guides/authentication">
  Learn about authentication and security
</Card>

</CardGroup>
```

### Example 3: mint.json Configuration

```json
{
  "$schema": "https://mintlify.com/schema.json",
  "name": "Your API Documentation",
  "logo": {
    "dark": "/logo/dark.svg",
    "light": "/logo/light.svg"
  },
  "favicon": "/favicon.svg",
  "colors": {
    "primary": "#0D9373",
    "light": "#07C983",
    "dark": "#0D9373"
  },
  "topbarLinks": [
    {
      "name": "Support",
      "url": "mailto:support@example.com"
    }
  ],
  "topbarCtaButton": {
    "name": "Dashboard",
    "url": "https://dashboard.example.com"
  },
  "tabs": [
    {
      "name": "API Reference",
      "url": "api-reference"
    },
    {
      "name": "Guides",
      "url": "guides"
    }
  ],
  "navigation": [
    {
      "group": "Get Started",
      "pages": [
        "introduction",
        "quickstart",
        "authentication"
      ]
    },
    {
      "group": "API Reference",
      "pages": [
        "api-reference/users",
        "api-reference/organizations",
        "api-reference/webhooks"
      ]
    },
    {
      "group": "Guides",
      "pages": [
        "guides/error-handling",
        "guides/rate-limiting",
        "guides/pagination"
      ]
    }
  ],
  "footerSocials": {
    "twitter": "https://twitter.com/example",
    "github": "https://github.com/example"
  },
  "analytics": {
    "posthog": {
      "apiKey": "phc_xxx"
    }
  },
  "api": {
    "baseUrl": "https://api.example.com",
    "auth": {
      "method": "bearer"
    }
  }
}
```

## Troubleshooting

### Mintlify build fails with frontmatter errors

Ensure all MDX files have valid YAML frontmatter with 'title' and 'description' fields. No tabs in YAML.

### Navigation doesn't show all pages

Update mint.json navigation array to explicitly list all MDX file paths without .mdx extension.

### Code syntax highlighting not working

Use full language names in code fences: typescript, javascript, python, bash (not ts, js, py, sh).

## Learn More

For additional documentation and resources, visit:

https://mintlify.com/docs