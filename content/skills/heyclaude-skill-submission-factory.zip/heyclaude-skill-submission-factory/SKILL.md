---
name: heyclaude-skill-submission-factory
description: Create portable Agent Skills, generate platform adapters, validate package metadata, and prepare issue-first HeyClaude submissions. Use when authoring a reusable skill for public registry distribution or adapting a SKILL.md package for Claude, Codex, Windsurf, Gemini, Cursor, or AGENTS-style context.
---

# HeyClaude Skill Submission Factory

Use this skill to create a portable Agent Skill and prepare a maintainer-reviewed HeyClaude submission.

## Workflow

1. Define the user, task, trigger language, and out-of-scope behavior.
2. Create one root folder containing `SKILL.md`.
3. Add YAML frontmatter with `name` and `description` only unless the target platform requires more.
4. Keep the body concise and procedural. Link optional resources from the body when they are needed.
5. Add optional resources only under `scripts/`, `references/`, `assets/`, or `agents/openai.yaml`.
6. Generate a compatibility table:
   - Claude: native Agent Skill
   - Codex/OpenAI: native Agent Skill
   - Windsurf: native Agent Skill
   - Gemini: adapter via .gemini/commands/*.toml or GEMINI.md
   - Cursor: `.cursor/rules/<skill-name>.mdc` adapter
   - Generic AGENTS: manual context adapter
7. Validate the package shape, frontmatter, referenced resources, and public-safe content.
8. Prepare HeyClaude issue fields from the canonical submit form. Do not publish directly.

## Cursor Adapter

When the user wants Cursor support, generate an `.mdc` rule with this shape:

```mdc
---
description: "Use this workflow when the user asks for <skill purpose>."
globs:
alwaysApply: false
---

# <Skill Title>

Follow the SKILL.md workflow as a scoped Cursor rule. This is an adapter, not a native Agent Skill install.
```

## Validation Rules

- The archive must contain one root folder.
- The root folder must contain `SKILL.md`.
- `SKILL.md` must have `name` and `description` frontmatter.
- Descriptions must be specific enough for agent selection.
- Public skills must not include private repo names, secrets, credentials, or internal operating details.
- Platform claims must distinguish native support from adapters.
- Submissions must remain issue-first and maintainer-reviewed.

## Output

Return:

- skill folder tree
- SKILL.md content
- optional resource list
- compatibility table
- Cursor adapter when requested
- HeyClaude submission fields
- validation results
