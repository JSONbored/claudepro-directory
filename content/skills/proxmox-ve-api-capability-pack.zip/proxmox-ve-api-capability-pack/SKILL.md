---
name: proxmox-ve-api-capability-pack
description: "Expert Proxmox VE API capability skill for VM/LXC lifecycle orchestration, task polling, auth safety, and cluster-aware operations."
---

## Knowledge Freshness

This capability pack is pinned to documentation verified on **2026-04-10**.
When upstream docs change, refresh endpoint contracts, examples, and constraints before using this skill for production changes.

## Retrieval Sources

- https://pve.proxmox.com/mediawiki/index.php?title=Proxmox_VE_API
- https://pve.proxmox.com/wiki/Main_Page
- https://pve.proxmox.com/pve-docs/

Always prefer direct retrieval from official docs/API references over model memory for limits, endpoint signatures, and behavior guarantees.

## Core Workflow

1. Confirm target version/runtime and pull latest official docs for the task scope.
2. Build an execution plan with explicit read-only discovery before any mutation.
3. Validate contracts, permissions, and safety constraints before applying changes.
4. Execute with deterministic checkpoints and rollback criteria.
5. Produce a verification report with evidence, caveats, and next actions.

## Overview

This capability pack teaches agents how to operate Proxmox VE safely and predictably through the API. It goes beyond generic automation by enforcing cluster-aware operational discipline.

## Capability Scope

- Token auth/session behavior and secure usage
- Task lifecycle semantics and polling strategies
- VM/LXC lifecycle orchestration patterns
- Migration/backup/restore safety constraints
- Failure classification and rollback protocol

## Compatibility

### Native

- **Claude Code / Claude**: native skill usage via `SKILL.md`.
- **Codex/OpenAI workflows**: compatible with Agent Skills-style `SKILL.md` content as reusable workflow instructions.

### Manual Adaptation

- **OpenClaw, Cursor, Windsurf, Gemini, and similar agents**: use the same skill content as a reusable prompt/workflow file when native skill import is unavailable.

## Production Rules

- Gate write operations behind pre-flight checks.
- Never assume synchronous completion for async tasks.
- Validate desired state after each task completion.
- Keep operations idempotent where possible.

## Troubleshooting

**Issue:** API call returns success but workload state is wrong  
**Fix:** Tie workflow completion to task result plus post-state verification.

**Issue:** Migration flakiness under load  
**Fix:** Add capacity and network health gates before migration.

**Issue:** Permission confusion across tokens  
**Fix:** Maintain explicit token-role matrix per workflow.

## Output Contract

1. Provide an implementation plan ordered by risk and dependency.
2. Provide exact production-ready config/commands with no placeholders.
3. Call out secrets, permissions, and least-privilege requirements.
4. Include rollback and recovery guidance for each risky step.

## Validation Checklist

- Verify all referenced docs/versions before applying changes.
- Run smoke checks for core user flow and error paths.
- Confirm observability/logging is enabled for changed components.
- Confirm security controls (auth, rate limits, input validation) still pass.
- Record final known limitations and follow-up actions.
