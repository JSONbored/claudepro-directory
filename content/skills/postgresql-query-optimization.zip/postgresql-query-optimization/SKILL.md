---
name: postgresql-query-optimization
description: Analyze and optimize PostgreSQL queries for OLTP and OLAP workloads with AI-assisted performance tuning, indexing strategies, and execution plan analysis.
---

# PostgreSQL Query Optimization Skill

## What This Skill Enables

Claude can analyze PostgreSQL query performance, interpret EXPLAIN plans, design optimal indexes, and tune database configurations for specific workloads (OLTP, OLAP, or hybrid). With expertise in PostgreSQL 16+ features including parallel query execution, JIT compilation, and advanced partitioning strategies, Claude helps achieve sub-millisecond query times for high-traffic applications.

## Prerequisites

**Required:**
- Claude Pro subscription or Claude Code CLI
- PostgreSQL 14+ installed (16+ recommended)
- Access to database with slow queries or performance issues
- Basic SQL knowledge

**What Claude handles automatically:**
- Analyzing EXPLAIN ANALYZE output
- Identifying missing or inefficient indexes
- Suggesting query rewrites for better performance
- Recommending configuration parameter tuning
- Detecting N+1 query problems
- Proposing table partitioning strategies
- Analyzing vacuum and autovacuum settings
- Identifying connection pooling needs

## How to Use This Skill

### Analyze Slow Query

**Prompt:** "My PostgreSQL query is taking 5 seconds. Here's the query: [paste query]. Analyze the execution plan and suggest optimizations."

Claude will:
1. Run EXPLAIN (ANALYZE, BUFFERS, VERBOSE)
2. Identify bottlenecks (seq scans, nested loops)
3. Suggest missing indexes with CREATE INDEX statements
4. Rewrite query if needed (JOIN order, subquery optimization)
5. Estimate performance improvement
6. Provide before/after comparison

### Index Strategy Design

**Prompt:** "Design an optimal indexing strategy for a high-traffic e-commerce database with 10M products. Include queries: product search by name, filter by category and price range, sort by popularity."

Claude will:
1. Analyze query patterns and access patterns
2. Create B-tree indexes for equality/range queries
3. Add GIN indexes for full-text search
4. Design composite indexes for multi-column filters
5. Include partial indexes for filtered queries
6. Add BRIN indexes for time-series data
7. Calculate index maintenance overhead

### Database Configuration Tuning

**Prompt:** "Tune PostgreSQL configuration for a 32GB RAM server running high-write OLTP workload with 200 concurrent connections."

Claude will:
1. Set shared_buffers (25% of RAM = 8GB)
2. Configure work_mem per connection
3. Adjust max_connections and connection pooling
4. Tune WAL settings for write performance
5. Configure autovacuum for high-write scenarios
6. Set effective_cache_size
7. Enable parallel query workers

### Query Rewriting for Performance

**Prompt:** "Rewrite this slow query to eliminate the N+1 problem: [paste ORM-generated query with multiple subqueries]."

Claude will:
1. Identify N+1 or N+M pattern
2. Convert subqueries to JOINs
3. Use CTEs for readability
4. Apply window functions for ranking
5. Implement LATERAL joins where appropriate
6. Add proper indexes for new query
7. Validate result correctness

## Tips for Best Results

1. **Always Use EXPLAIN ANALYZE**: Share full EXPLAIN (ANALYZE, BUFFERS) output with Claude. The BUFFERS option reveals I/O patterns crucial for optimization.

2. **Provide Table Schemas**: Include CREATE TABLE statements and existing indexes. Claude needs column types and constraints for accurate recommendations.

3. **Share Query Frequency**: Mention if a query runs once per day or 10,000 times per second. Optimization strategies differ dramatically.

4. **Workload Type Matters**: OLTP (many small transactions) and OLAP (complex analytics) require opposite tuning. Specify your workload.

5. **Include Real Data Volume**: "1000 rows" vs "100M rows" changes everything. Share actual table sizes with pg_size_pretty.

6. **Monitor After Changes**: Ask Claude to generate monitoring queries to verify improvements don't cause regressions elsewhere.

## Common Workflows

### Complete Performance Audit
```
"Perform a comprehensive PostgreSQL performance audit:
1. Identify top 10 slowest queries from pg_stat_statements
2. Analyze EXPLAIN plans for each
3. Detect missing indexes with pg_stat_user_tables
4. Find bloated tables needing VACUUM FULL
5. Review configuration parameters
6. Check for long-running transactions blocking others
7. Provide prioritized optimization action plan"
```

### Time-Series Optimization
```
"Optimize PostgreSQL for time-series data:
1. 100M rows of sensor data per month
2. Queries filter by device_id and time range
3. Need 90-day retention with automated archival
4. Implement declarative partitioning by month
5. Add BRIN indexes on timestamp columns
6. Configure autovacuum for partition management
7. Create aggregate materialized views"
```

### Full-Text Search Tuning
```
"Build high-performance full-text search:
1. Search across title, description, tags fields
2. Support phrase queries and ranking
3. Handle 50M documents
4. Sub-100ms query response time
5. Use GIN indexes with tsvector
6. Implement trigram similarity for typo tolerance
7. Add weighted search across columns"
```

### Replication Lag Analysis
```
"Debug PostgreSQL replication lag:
1. Replica is 30 seconds behind primary
2. Analyze pg_stat_replication metrics
3. Check for long-running queries on replica
4. Identify write-heavy tables causing lag
5. Tune max_wal_senders and wal_keep_size
6. Recommend synchronous vs asynchronous replication
7. Implement connection pooling strategy"
```

## Troubleshooting

**Issue:** Query still slow after adding index
**Solution:** Index may not be used. Check EXPLAIN plan shows Index Scan (not Seq Scan). Run ANALYZE to update statistics. Consider index-only scans with INCLUDE columns or covering indexes.

**Issue:** Database running out of connections
**Solution:** Implement connection pooling with PgBouncer or pgpool-II. Reduce max_connections and increase per-connection work_mem. Fix application connection leaks.

**Issue:** Autovacuum not keeping up
**Solution:** Lower autovacuum_vacuum_scale_factor and autovacuum_vacuum_threshold for high-write tables. Increase autovacuum_max_workers. Consider manual VACUUM during maintenance windows.

**Issue:** Query fast in development, slow in production
**Solution:** Production has different data distribution. Run ANALYZE on production. Check if production has proper indexes. Compare EXPLAIN plans between environments.

**Issue:** Disk I/O bottleneck
**Solution:** Increase shared_buffers for caching. Use NVMe SSDs. Consider table partitioning to reduce I/O per query. Implement read replicas for read-heavy workloads.

**Issue:** Connection pool exhausted
**Solution:** Tune pool size based on `connections = ((core_count * 2) + effective_spindle_count)`. Implement queue_timeout. Add monitoring for pool saturation.

## Learn More

- [PostgreSQL Performance Tuning Guide](https://www.postgresql.org/docs/current/performance-tips.html)
- [Use The Index, Luke! - SQL Indexing Guide](https://use-the-index-luke.com/)
- [Depesz EXPLAIN Visualizer](https://explain.depesz.com/)
- [PGTune Configuration Calculator](https://pgtune.leopard.in.ua/)
- [pgAdmin Query Tool](https://www.pgadmin.org/)
- [pg_stat_statements Extension](https://www.postgresql.org/docs/current/pgstatstatements.html)


## Prerequisites

- PostgreSQL 14+ (16+ recommended)
- pg_stat_statements extension
- EXPLAIN access permissions
- psql or database client

## Key Features

- EXPLAIN plan analysis and visualization
- Automatic index recommendation
- Workload-specific tuning (OLTP/OLAP)
- Query rewriting for performance

## Use Cases

- Optimize slow database queries
- Design indexing strategies
- Tune PostgreSQL configuration

## Examples

### Example 1: Analyze Query Performance

```sql
-- Run with EXPLAIN ANALYZE to get actual execution times
EXPLAIN (ANALYZE, BUFFERS, VERBOSE)
SELECT p.name, c.name as category, p.price
FROM products p
JOIN categories c ON p.category_id = c.id
WHERE p.price BETWEEN 100 AND 500
  AND c.name = 'Electronics'
ORDER BY p.created_at DESC
LIMIT 20;

-- Check if indexes are being used
SELECT schemaname, tablename, indexname, idx_scan, idx_tup_read, idx_tup_fetch
FROM pg_stat_user_indexes
WHERE schemaname = 'public'
ORDER BY idx_scan ASC;
```

### Example 2: Create Optimal Indexes

```sql
-- Composite index for filtered queries
CREATE INDEX idx_products_category_price 
ON products(category_id, price) 
WHERE price IS NOT NULL;

-- Partial index for active records only
CREATE INDEX idx_products_active 
ON products(created_at) 
WHERE status = 'active';

-- GIN index for full-text search
CREATE INDEX idx_products_search 
ON products USING GIN(to_tsvector('english', name || ' ' || description));

-- BRIN index for time-series data
CREATE INDEX idx_events_timestamp 
ON events USING BRIN(created_at);

-- Covering index (index-only scan)
CREATE INDEX idx_products_category_include 
ON products(category_id) 
INCLUDE (name, price);
```

### Example 3: Find Slow Queries

```sql
-- Enable pg_stat_statements first
CREATE EXTENSION IF NOT EXISTS pg_stat_statements;

-- Find slowest queries by total time
SELECT 
  query,
  calls,
  total_exec_time,
  mean_exec_time,
  max_exec_time,
  stddev_exec_time
FROM pg_stat_statements
ORDER BY total_exec_time DESC
LIMIT 10;

-- Find queries with high I/O
SELECT 
  query,
  calls,
  shared_blks_hit,
  shared_blks_read,
  (shared_blks_hit::float / NULLIF(shared_blks_hit + shared_blks_read, 0)) * 100 AS cache_hit_ratio
FROM pg_stat_statements
WHERE shared_blks_read > 0
ORDER BY shared_blks_read DESC
LIMIT 10;
```

### Example 4: Configuration Tuning

```sql
-- OLTP Workload Configuration (postgresql.conf)
-- For 32GB RAM, 8 cores, NVMe SSD

-- Memory Settings
shared_buffers = 8GB                    -- 25% of RAM
effective_cache_size = 24GB             -- 75% of RAM
work_mem = 64MB                         -- Per operation
maintenance_work_mem = 2GB              -- For VACUUM, CREATE INDEX

-- Write Performance
wal_buffers = 16MB
checkpoint_completion_target = 0.9
max_wal_size = 4GB
min_wal_size = 1GB

-- Query Planner
random_page_cost = 1.1                  -- For SSD
effective_io_concurrency = 200          -- For SSD

-- Connections
max_connections = 200

-- Parallelism
max_worker_processes = 8
max_parallel_workers_per_gather = 4
max_parallel_workers = 8

-- Autovacuum (high-write workload)
autovacuum_max_workers = 4
autovacuum_naptime = 10s
autovacuum_vacuum_scale_factor = 0.05
autovacuum_analyze_scale_factor = 0.02
```

## Troubleshooting

### Index not being used by query planner

Run ANALYZE to update statistics, check WHERE clause matches index columns exactly, lower random_page_cost for SSDs, or use pg_hint_plan extension to force index usage.

### Out of memory errors

Reduce work_mem or max_connections. Implement connection pooling with PgBouncer. Check for memory-intensive queries using hash joins or sorts.

### Slow VACUUM operations

Increase maintenance_work_mem, run VACUUM during off-peak hours, consider VACUUM FREEZE for old tables, or use pg_repack for online table reorganization.

## Learn More

For additional documentation and resources, visit:

https://www.postgresql.org/docs/current/performance-tips.html