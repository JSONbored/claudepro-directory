---
name: google-workspace-gemini-automation
description: "Create useful Gemini-powered Google Workspace automations for docs, sheets, email triage, and internal workflow productivity."
---

## Overview

This skill helps AI agents build practical Google Workspace automations using Gemini. It focuses on workflows teams actually run: reporting, triage, routing, summarization, and structured content generation.

## Compatibility

### Native

- **Claude Code / Claude**: native skill usage via `SKILL.md`.
- **Codex/OpenAI workflows**: compatible with Agent Skills-style `SKILL.md` content as reusable workflow instructions.

### Manual Adaptation

- **OpenClaw, Cursor, Windsurf, Gemini, and similar agents**: use the same skill content as a reusable prompt/workflow file when native skill import is unavailable.

## Prerequisites

- Defined source systems and destination artifacts
- Data classification and privacy constraints
- Human reviewers for quality-sensitive outputs

## What This Skill Delivers

- Workflow decomposition for Docs/Sheets/Gmail/Drive tasks
- Prompt and schema patterns for reliable output structure
- Quality gates and approval loops
- Monitoring plan for failures, drift, and cost anomalies

## How to Use This Skill

1. Map workflow trigger, inputs, and output destination.
2. Define target schema for generated content.
3. Add policy checks for sensitive data.
4. Add human review for high-impact decisions.
5. Track execution outcomes and iterate prompts safely.

## Troubleshooting

**Issue:** Output quality varies by run  
**Fix:** Tighten schema constraints and add post-generation validation checks.

**Issue:** Automation creates noisy or irrelevant docs  
**Fix:** Refine source filtering and enforce clear acceptance criteria.

**Issue:** Costs rise unexpectedly  
**Fix:** Add workload bucketing and caching for repeat context segments.

## Knowledge Freshness

Treat tooling details as time-sensitive. Re-validate APIs, limits, pricing, auth models, and deployment flags immediately before implementation. If docs conflict with prior memory, follow current official docs and release notes.

## Retrieval Sources

- https://ai.google.dev/gemini-api/docs

## Output Contract

1. Return a concrete plan with implementation order.
2. Provide production-ready commands/config/code snippets (not placeholders).
3. Include explicit assumptions and unresolved risks.
4. Include a verification checklist with pass/fail criteria.

## Quality Gates

- All commands are copy/paste ready.
- Security-sensitive steps call out secret handling and least privilege.
- Version-sensitive guidance cites current docs used.
- Rollback path is included for risky changes.
- Final output includes quick validation commands/tests.
