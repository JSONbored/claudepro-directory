---
name: zod-schema-validator
description: Build type-safe runtime validation with Zod for APIs, forms, and data pipelines with TypeScript 5.5+ integration and automatic type inference.
---

# Zod Schema Validator Skill

## What This Skill Enables

Claude can build comprehensive validation schemas using Zod, the TypeScript-first validation library tested against TypeScript v5.5+. Zod provides runtime validation that matches compile-time types, enabling you to validate untrusted data (API inputs, user forms, external integrations) while maintaining end-to-end type safety. With zero dependencies and automatic type inference, Zod eliminates the gap between static types and runtime reality.

## Prerequisites

**Required:**
- Claude Pro subscription or Claude Code CLI
- TypeScript 5.0+ (5.5+ recommended)
- Node.js 18+ or modern browser
- Basic TypeScript knowledge

**What Claude handles automatically:**
- Writing Zod schemas with proper validators
- Inferring TypeScript types from schemas
- Adding custom validation logic with refinements
- Generating error messages in multiple formats
- Creating reusable schema compositions
- Implementing async validation
- Adding transforms for data coercion
- Integrating with React Hook Form or tRPC

## How to Use This Skill

### Basic Schema Creation

**Prompt:** "Create Zod schemas for a user registration API that validates email, password (min 8 chars, requires number and special char), age (18-100), and optional phone number."

Claude will:
1. Write Zod schema with proper validators
2. Add regex patterns for email and password
3. Include range validation for age
4. Make phone number optional
5. Generate custom error messages
6. Infer TypeScript type from schema
7. Show validation usage examples

### Form Validation with React Hook Form

**Prompt:** "Build a React form with Zod validation for: name, email, address (street, city, state, zip), and checkbox for terms acceptance. Integrate with React Hook Form and show field-level errors."

Claude will:
1. Create nested Zod schema for address
2. Set up React Hook Form with zodResolver
3. Add real-time validation on blur
4. Display error messages per field
5. Prevent submission until valid
6. Include TypeScript types
7. Add accessible error announcements

### API Request/Response Validation

**Prompt:** "Create Zod schemas for a REST API with request validation and response parsing. Include pagination parameters, filters, and error handling."

Claude will:
1. Define request body schemas
2. Create query parameter validators
3. Add response schema with safeParse
4. Handle validation errors gracefully
5. Include pagination metadata
6. Add discriminated unions for responses
7. Generate OpenAPI types from schemas

### Complex Business Logic Validation

**Prompt:** "Build a Zod schema for order validation where: if payment method is 'credit_card', require card details; if 'paypal', require email; shipping date must be after today; total must match items sum."

Claude will:
1. Use discriminated unions for payment methods
2. Add conditional validation with refine()
3. Implement cross-field validation
4. Calculate and validate totals
5. Add date comparison logic
6. Provide clear error paths
7. Include async validation for external checks

## Tips for Best Results

1. **Infer Types, Don't Duplicate**: Always use `z.infer<typeof schema>` instead of defining types manually. This ensures runtime validation matches compile-time types.

2. **Use `.safeParse()` for Untrusted Data**: In API routes or external inputs, use `safeParse()` instead of `parse()` to avoid throwing exceptions. Handle validation errors gracefully.

3. **Custom Error Messages**: Request custom error messages with `.min(8, { message: 'Password must be at least 8 characters' })` for better UX.

4. **Refinements for Complex Logic**: Use `.refine()` or `.superRefine()` for validation that involves multiple fields or external calls.

5. **Reusable Schemas**: Create base schemas and extend them with `.extend()` or compose with `.merge()` to avoid duplication.

6. **Transforms for Coercion**: Use `.transform()` to normalize data (trim strings, parse numbers) before validation.

## Common Workflows

### E-Commerce Checkout Validation
```
"Create complete Zod validation for checkout flow:
1. Customer info: email, phone, billing address
2. Shipping: address with validation (can't be PO box), preferred delivery date
3. Payment: discriminated union for credit card, PayPal, crypto
4. Items: array of products with quantity (min 1, max 10), size, color
5. Promo code: optional, alphanumeric, validate against API
6. Total must match cart calculation
7. Accept terms and conditions (required)"
```

### API Gateway Validation Layer
```
"Build API validation middleware with Zod:
1. Validate request headers (auth token, content-type)
2. Parse and validate query parameters with coercion
3. Validate request body based on endpoint
4. Add rate limiting metadata validation
5. Validate response format before sending to client
6. Log validation errors with request context
7. Return standardized error responses"
```

### Database Input Sanitization
```
"Create Zod schemas for database operations:
1. User input sanitization before INSERT
2. Strip dangerous characters from strings
3. Validate foreign key relationships exist
4. Ensure email uniqueness with async validator
5. Transform dates to ISO format
6. Validate JSON columns match expected structure
7. Add database constraint validation"
```

### File Upload Validation
```
"Build file upload validator with Zod:
1. Validate MIME types (images: PNG, JPG, WebP)
2. Check file size (max 5MB)
3. Validate image dimensions (min 800x600, max 4000x4000)
4. Sanitize filename (alphanumeric, hyphens, underscores)
5. Validate metadata (EXIF data)
6. Check for malware signatures
7. Transform to standard format"
```

## Troubleshooting

**Issue:** Type inference not working
**Solution:** Ensure TypeScript version is 5.0+. Use `z.infer<typeof schema>` correctly. Check tsconfig.json has `strict: true`. Update Zod to latest version.

**Issue:** Validation errors not showing custom messages
**Solution:** Add message parameter to validators: `.min(8, { message: '...' })`. Use `error.format()` to get structured errors. Check error path matches form field names.

**Issue:** Async validation not working
**Solution:** Use `.refine()` with async function, not `.transform()`. Ensure you `await` the parse result. Consider using `.parseAsync()` or `.safeParseAsync()`.

**Issue:** Performance slow with large arrays
**Solution:** Use `.nonempty()` instead of `.min(1)` for faster validation. Implement pagination. Consider lazy validation with `.lazy()` for recursive structures.

**Issue:** Optional fields not working correctly
**Solution:** Use `.optional()` for truly optional fields, `.nullable()` for null values, `.default()` for default values. Don't mix `.optional()` with `.nullable()` unless you mean to accept both.

**Issue:** Union types confusing in errors
**Solution:** Use discriminated unions with `.discriminatedUnion()` for better error messages. Add explicit type checking before validation. Provide user-friendly labels.

## Learn More

- [Zod Official Documentation](https://zod.dev/)
- [Zod GitHub Repository](https://github.com/colinhacks/zod)
- [React Hook Form + Zod Integration](https://react-hook-form.com/get-started#SchemaValidation)
- [tRPC + Zod Guide](https://trpc.io/docs/server/validators)
- [Zod to JSON Schema](https://github.com/StefanTerdell/zod-to-json-schema)
- [Zod Error Formatting](https://zod.dev/ERROR_HANDLING)


## Prerequisites

- TypeScript 5.0+
- zod ^3.22.0
- Node.js 18+ or modern browser

## Key Features

- TypeScript-first with automatic type inference
- Zero dependencies, 8kb minified
- Composable schemas with .extend() and .merge()
- Custom validation with .refine() and async support

## Use Cases

- API request/response validation
- Form validation with error messages
- Database input sanitization

## Examples

### Example 1: User Registration Schema

```typescript
import { z } from 'zod';

const passwordSchema = z
  .string()
  .min(8, 'Password must be at least 8 characters')
  .regex(/[0-9]/, 'Password must contain a number')
  .regex(/[^a-zA-Z0-9]/, 'Password must contain a special character');

const userRegistrationSchema = z.object({
  email: z.string().email('Invalid email address'),
  password: passwordSchema,
  confirmPassword: z.string(),
  age: z.number().int().min(18, 'Must be 18 or older').max(100),
  phone: z.string().regex(/^\+?[1-9]\d{1,14}$/).optional(),
  acceptTerms: z.literal(true, {
    errorMap: () => ({ message: 'You must accept the terms' }),
  }),
}).refine((data) => data.password === data.confirmPassword, {
  message: 'Passwords do not match',
  path: ['confirmPassword'],
});

type UserRegistration = z.infer<typeof userRegistrationSchema>;

// Usage
const result = userRegistrationSchema.safeParse({
  email: 'user@example.com',
  password: 'SecureP@ss1',
  confirmPassword: 'SecureP@ss1',
  age: 25,
  acceptTerms: true,
});

if (!result.success) {
  console.error(result.error.format());
} else {
  console.log('Valid user:', result.data);
}
```

### Example 2: React Hook Form Integration

```typescript
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';

const formSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  email: z.string().email(),
  address: z.object({
    street: z.string().min(5),
    city: z.string().min(2),
    state: z.string().length(2, 'Use 2-letter state code'),
    zip: z.string().regex(/^\d{5}(-\d{4})?$/, 'Invalid ZIP code'),
  }),
});

type FormData = z.infer<typeof formSchema>;

export function RegistrationForm() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(formSchema),
  });

  const onSubmit = (data: FormData) => {
    console.log('Valid form data:', data);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <input {...register('name')} />
      {errors.name && <span>{errors.name.message}</span>}

      <input {...register('email')} />
      {errors.email && <span>{errors.email.message}</span>}

      <input {...register('address.street')} placeholder="Street" />
      {errors.address?.street && <span>{errors.address.street.message}</span>}

      {/* ... other fields ... */}

      <button type="submit">Submit</button>
    </form>
  );
}
```

### Example 3: API Validation Middleware

```typescript
import { z } from 'zod';
import { Request, Response, NextFunction } from 'express';

const createUserSchema = z.object({
  body: z.object({
    name: z.string().min(2),
    email: z.string().email(),
    role: z.enum(['user', 'admin']).default('user'),
  }),
  query: z.object({
    sendWelcomeEmail: z
      .string()
      .transform((val) => val === 'true')
      .default('false'),
  }),
});

type CreateUserRequest = z.infer<typeof createUserSchema>;

export const validateRequest =
  (schema: z.ZodSchema) =>
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const result = await schema.parseAsync({
        body: req.body,
        query: req.query,
        params: req.params,
      });

      req.body = result.body;
      req.query = result.query as any;
      next();
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({
          error: 'Validation failed',
          details: error.format(),
        });
      } else {
        next(error);
      }
    }
  };

// Usage
app.post('/users', validateRequest(createUserSchema), async (req, res) => {
  const { name, email, role } = req.body;
  // Data is validated and typed
  const user = await createUser({ name, email, role });
  res.json(user);
});
```

### Example 4: Discriminated Union for Payments

```typescript
import { z } from 'zod';

const creditCardPayment = z.object({
  method: z.literal('credit_card'),
  cardNumber: z.string().regex(/^\d{16}$/),
  expiryMonth: z.number().min(1).max(12),
  expiryYear: z.number().min(2025),
  cvv: z.string().regex(/^\d{3,4}$/),
});

const paypalPayment = z.object({
  method: z.literal('paypal'),
  email: z.string().email(),
});

const cryptoPayment = z.object({
  method: z.literal('crypto'),
  walletAddress: z.string().regex(/^0x[a-fA-F0-9]{40}$/),
  cryptocurrency: z.enum(['BTC', 'ETH', 'USDC']),
});

const paymentSchema = z.discriminatedUnion('method', [
  creditCardPayment,
  paypalPayment,
  cryptoPayment,
]);

type Payment = z.infer<typeof paymentSchema>;

// TypeScript knows the shape based on method
function processPayment(payment: Payment) {
  switch (payment.method) {
    case 'credit_card':
      return chargeCreditCard(payment.cardNumber, payment.cvv);
    case 'paypal':
      return chargePayPal(payment.email);
    case 'crypto':
      return chargeCrypto(payment.walletAddress);
  }
}
```

## Troubleshooting

### Type inference returns 'any'

Check TypeScript version is 5.0+. Ensure you're using 'z.infer<typeof schema>' correctly. Update tsconfig.json with strict: true.

### Optional fields not working

Use .optional() for optional, .nullable() for null, .default() for defaults. Don't chain .optional().nullable() unless you need both undefined and null.

### Async validation failing

Use .refine() with async callback, call .parseAsync() or .safeParseAsync(), ensure you await the result.

## Learn More

For additional documentation and resources, visit:

https://zod.dev/