---
name: log-parsing-incident-timeline
description: Parse web/app/system logs into structured incidents and timelines with anomaly hints.
---

# Log Parsing & Incident Timeline Skill

## What This Skill Enables

Claude can parse application logs, server logs, and system logs to extract errors, create incident timelines, identify patterns, and correlate events across distributed systems. Transform raw log data into actionable insights.

## Prerequisites

**Required:**
- Claude Pro subscription
- Code Interpreter feature enabled
- Log files uploaded (text, JSON, or compressed)

**What Claude handles:**
- Installing log parsing tools (grep, awk, jq, logparser)
- Pattern matching and extraction
- Timestamp parsing and correlation
- Error aggregation and analysis
- Timeline generation

## How to Use This Skill

### Extract Errors from Logs

**Prompt:** "Find all errors in this application log from the past hour. Group by error type and show frequency."

Claude will:
1. Parse log timestamps
2. Filter to last hour
3. Extract error messages
4. Group and count
5. Present sorted by frequency

### Create Incident Timeline

**Prompt:** "Create a timeline of what happened during the outage (2pm-3pm):
- Filter to that time range
- Show key events (errors, warnings, restarts)
- Correlate across multiple log files
- Present chronologically"

Claude will:
1. Parse multiple log sources
2. Filter by time range
3. Extract significant events
4. Merge and sort chronologically
5. Create incident timeline

### Analyze Request Flow

**Prompt:** "Trace request ID 'abc123' through all log files. Show the complete journey with timestamps and any errors encountered."

Claude will:
1. Search for request ID across files
2. Extract all matching lines
3. Sort by timestamp
4. Identify errors or anomalies
5. Show complete flow

### Performance Analysis

**Prompt:** "Analyze response times in this access log:
- Calculate p50, p95, p99 percentiles
- Identify slowest requests
- Show distribution histogram
- Flag requests over 1 second"

Claude will:
1. Extract response time data
2. Calculate statistics
3. Identify outliers
4. Create visualization
5. Report findings

## Common Workflows

### Post-Incident Analysis
```
"Analyze logs from the incident:
1. Extract all errors between 14:00-15:00
2. Identify first error that occurred
3. Show cascade of subsequent errors
4. Correlate with deployment timestamp
5. Create incident report with timeline"
```

### Security Audit
```
"Audit access logs for security issues:
1. Find failed login attempts (3+ in 5 min)
2. Identify IP addresses with suspicious patterns
3. Detect potential SQL injection attempts
4. Flag unusual user agent strings
5. Generate security report"
```

### Error Aggregation
```
"Aggregate errors from past 7 days:
1. Group by error type/stack trace
2. Count occurrences over time
3. Identify trends (increasing/decreasing)
4. Show top 10 most common errors
5. Export as CSV for tracking"
```

### Multi-Service Correlation
```
"Correlate logs from:
- API gateway (nginx)
- Application server (node.js)
- Database (postgres)
- Cache (redis)
For request ID xyz789, show complete flow across all services."
```

## Log Formats Supported

### Common Formats
- Apache/Nginx access logs
- JSON structured logs
- Syslog format
- Application logs (various formats)
- AWS CloudWatch logs
- Docker container logs

### Custom Formats
- Claude can parse custom log formats
- Provide sample line and field descriptions
- Define regex patterns or delimiters

## Tips for Best Results

1. **Provide Context**: Describe log format and what you're looking for
2. **Time Ranges**: Be specific about time periods ("last hour", "between 2-3pm EST")
3. **Sample Lines**: Show Claude a few example log lines
4. **Identifiers**: Mention correlation IDs (request ID, user ID, session ID)
5. **Large Files**: For huge logs, ask Claude to sample or filter first
6. **Compressed Logs**: Claude can handle .gz files directly
7. **Multiple Files**: Upload related files together for correlation

## Advanced Analysis

### Pattern Detection
- Anomaly detection in log volume
- Unusual pattern recognition
- Cyclic pattern identification
- Outlier detection

### Correlation Techniques
- Cross-service request tracing
- Time-based event correlation
- User session reconstruction
- Dependency mapping

### Filtering & Extraction
- Regex-based pattern matching
- JSON path extraction
- Field parsing and normalization
- PII redaction

## Troubleshooting

**Issue:** Timestamps in different formats across logs
**Solution:** Tell Claude the format: "Timestamps are in ISO 8601 in app.log but Unix epoch in system.log"

**Issue:** Log files too large to process
**Solution:** "Sample every 10th line" or "Filter to errors only first" or "Process in 1-hour chunks"

**Issue:** Can't find specific error messages
**Solution:** Provide example error text or pattern: "Look for lines containing '500' or 'exception' or 'fatal'"

**Issue:** Multiple services use different request ID fields
**Solution:** Map them: "request_id in API logs, correlation_id in app logs, trace_id in database logs"

**Issue:** Logs contain sensitive data
**Solution:** "Redact IP addresses, emails, and API keys before analysis" or "Mask PII fields"

**Issue:** Time zone confusion
**Solution:** Specify: "All timestamps are in UTC" or "Convert to Eastern Time for analysis"

## Learn More

- [Log Analysis Best Practices](https://www.loggly.com/ultimate-guide/analyzing-log-data/) - Comprehensive guide
- [jq Manual](https://stedolan.github.io/jq/manual/) - JSON log parsing
- [ripgrep Guide](https://github.com/BurntSushi/ripgrep) - Fast log searching
- [Log Parsing Patterns](https://logz.io/blog/logstash-grok/) - Common log patterns
- [Distributed Tracing](https://opentelemetry.io/docs/concepts/observability-primer/#distributed-traces) - Request correlation


## Prerequisites

- ripgrep (rg)
- jq (optional)
- bash or Python 3.11+

## Key Features

- ripgrep-based fast filtering
- Session/request correlation
- Timeline generation
- PII/secret redaction

## Use Cases

- Post-incident analysis
- Live debugging
- Compliance reporting

## Examples

### Example 1: Extract errors and build a simple timeline

```bash
# Filter 5xx from nginx and sort by time
rg -n ' 5\d\d ' access.log | awk '{print $4, $5, $9, $7}' | sort > timeline.txt
head -n 5 timeline.txt
```

## Troubleshooting

### ripgrep finds no matches in logs with known content

Check for encoding issues, try case-insensitive search with -i flag, test regex pattern with small sample first using rg -A 2.

### Timestamps in multiple formats causing incorrect sorting

Parse all timestamps to Unix epoch or ISO 8601 format first, then sort numerically before building timeline.

### ripgrep regex pattern not matching expected lines

Use rg --pcre2 for Perl-compatible regex, or simplify patterns and test with rg -o to show only matched parts.

### jq command fails with parse error on log JSON

Use jq -R for raw input if logs are line-delimited JSON, not pure JSON array; try jq -s for slurp mode on multiple objects.

### Log correlation fails across microservices with different IDs

Map correlation IDs in preprocessing step: create lookup table linking request_id, trace_id, correlation_id before timeline merge.

## Learn More

For additional documentation and resources, visit:

https://github.com/BurntSushi/ripgrep