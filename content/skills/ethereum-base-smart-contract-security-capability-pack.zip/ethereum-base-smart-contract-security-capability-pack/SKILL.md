---
name: ethereum-base-smart-contract-security-capability-pack
description: "Expert EVM capability skill for secure contract architecture across Ethereum and Base, including Foundry testing and operational controls."
---

## Knowledge Freshness

This capability pack is pinned to documentation verified on **2026-04-10**.
When upstream docs change, refresh endpoint contracts, examples, and constraints before using this skill for production changes.

## Retrieval Sources

- https://ethereum.org/developers/docs/
- https://book.getfoundry.sh/
- https://docs.openzeppelin.com/contracts
- https://docs.base.org/get-started/deploy-smart-contracts

Always prefer direct retrieval from official docs/API references over model memory for limits, endpoint signatures, and behavior guarantees.

## Core Workflow

1. Confirm target version/runtime and pull latest official docs for the task scope.
2. Build an execution plan with explicit read-only discovery before any mutation.
3. Validate contracts, permissions, and safety constraints before applying changes.
4. Execute with deterministic checkpoints and rollback criteria.
5. Produce a verification report with evidence, caveats, and next actions.

## Overview

This capability pack teaches agents to reason about Solidity security at protocol depth across Ethereum and Base environments. It combines architecture discipline, robust testing, and safer operational rollout.

## Capability Scope

- Threat modeling and trust assumptions
- Permission and upgrade model hardening
- Arithmetic/oracle/reentrancy/griefing defense strategies
- Foundry unit/fuzz/invariant methodology
- Deployment, monitoring, and emergency controls

## Compatibility

### Native

- **Claude Code / Claude**: native skill usage via `SKILL.md`.
- **Codex/OpenAI workflows**: compatible with Agent Skills-style `SKILL.md` content as reusable workflow instructions.

### Manual Adaptation

- **OpenClaw, Cursor, Windsurf, Gemini, and similar agents**: use the same skill content as a reusable prompt/workflow file when native skill import is unavailable.

## Production Rules

- Treat invariant violations as release blockers.
- Minimize privileged operations and centralization risk.
- Verify deployment config parity with audited assumptions.
- Maintain emergency pathways (pause/kill-switch) with governance constraints.

## Troubleshooting

**Issue:** Safe tests pass but adversarial behavior still possible  
**Fix:** Expand fuzz + invariant suites and include cross-contract interaction scenarios.

**Issue:** Upgrade path introduces hidden risk  
**Fix:** Add storage-layout and permission diff checks to release gating.

**Issue:** Incident response is untested  
**Fix:** Simulate emergency controls before mainnet launch.

## Output Contract

1. Provide an implementation plan ordered by risk and dependency.
2. Provide exact production-ready config/commands with no placeholders.
3. Call out secrets, permissions, and least-privilege requirements.
4. Include rollback and recovery guidance for each risky step.

## Validation Checklist

- Verify all referenced docs/versions before applying changes.
- Run smoke checks for core user flow and error paths.
- Confirm observability/logging is enabled for changed components.
- Confirm security controls (auth, rate limits, input validation) still pass.
- Record final known limitations and follow-up actions.
