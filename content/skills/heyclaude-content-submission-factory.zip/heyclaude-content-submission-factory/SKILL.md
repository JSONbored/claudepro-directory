---
name: heyclaude-content-submission-factory
description: Use when preparing complete, source-backed HeyClaude registry submissions across agents, MCP servers, tools, skills, rules, commands, hooks, guides, collections, and statuslines.
---

# HeyClaude Content Submission Factory

Use this skill when preparing a new HeyClaude registry submission or improving an existing listing. The output is a reviewed submission draft, not a direct publication path.

## Workflow

1. Identify the best HeyClaude category from source evidence.
2. Collect canonical public sources: official docs, repo, package, demo, or vendor page.
3. Extract only public facts. Never include secrets, private repo names, customer data, or internal URLs.
4. Add brand metadata only when safe: brand name, canonical brand domain, and official source URLs.
5. Write original summary copy. Do not mirror third-party pages.
6. Draft SEO fields from source-backed facts.
7. If the HeyClaude MCP server is available, call get_submission_schema, search_duplicate_entries, validate_submission_draft, and build_submission_urls to verify field shape, duplicate risk, and handoff URLs.
8. Create HeyClaude submission fields and an issue-first submission URL.

## Supported Categories

- agents
- mcp
- tools
- skills
- rules
- commands
- hooks
- guides
- collections
- statuslines

Jobs are out of scope. Use HeyClaude's jobs lead workflow for jobs.

## Required Output

Return a compact packet:

```yaml
category: mcp
title: Example MCP Server
slug: example-mcp-server
description: Short source-backed summary.
cardDescription: One-line preview text.
sourceUrl: https://example.com/docs/mcp
documentationUrl: https://example.com/docs
repoUrl: https://github.com/example/example
brandName: Example
brandDomain: example.com
tags:
  - mcp
  - automation
seoTitle: Example MCP Server for Claude
seoDescription: Source-backed description suitable for search previews.
maintainerNotes: Why this belongs in HeyClaude and what still needs review.
```

## Rules

- Do not auto-publish registry content.
- Do not create PRs, create GitHub issues, write local files, or mutate project config.
- Do not claim compatibility, package verification, checksums, or first-party status without evidence.
- Prefer blank brand fields over guessed brand domains.
- If a submission is actually an MCP server, CLI, or tool, do not label it as a skill unless it ships a valid SKILL.md package.

## MCP-Assisted Path

When an MCP client has the HeyClaude MCP server configured, use it as the source of truth for registry submission structure:

- get_submission_schema for required and optional fields by category.
- search_duplicate_entries before drafting a new listing.
- validate_submission_draft to catch malformed fields before handoff.
- build_submission_urls to generate review URLs without creating GitHub issues directly.

If the MCP server is unavailable, continue with the issue-first draft packet and explicitly mark validation as manual.

See references/category-fields.md for category notes.
