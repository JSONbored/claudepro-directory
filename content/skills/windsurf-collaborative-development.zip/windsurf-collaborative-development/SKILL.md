---
name: windsurf-collaborative-development
description: "Master collaborative AI-assisted development with Windsurf IDE's Cascade AI, multi-file context awareness, and Flow patterns for team workflows."
---

# Windsurf AI-Native Collaborative Development Skill

## What This Skill Enables

Claude can guide you through Windsurf's AI-native development environment, featuring Cascade AI for context-aware multi-file operations, Flow collaboration patterns for team coordination, and intelligent code navigation. Windsurf is emerging as a powerful alternative to GitHub Copilot in 2025, with superior multi-file refactoring and real-time collaboration features.

## Prerequisites

**Required:**
- Windsurf IDE installed (download from codeium.com/windsurf)
- Active project/codebase
- Basic understanding of your tech stack

**What Claude helps you master:**
- Cascade AI prompts for multi-file operations
- Flow sessions for team collaboration
- Context-aware code navigation
- Intelligent refactoring workflows
- AI-assisted debugging patterns
- Code review with Cascade

## How to Use This Skill

### Multi-File Refactoring with Cascade

**Prompt:** "I need to refactor our authentication system from NextAuth to better-auth v1.3.9. Walk me through using Cascade AI to update all files while maintaining existing functionality."

Claude will guide you to:
1. Select all auth-related files in Windsurf sidebar (Cmd/Ctrl+Click)
2. Open Cascade panel (Cmd/Ctrl+K)
3. Use specific Cascade prompt:
   ```
   Refactor authentication across these files to use better-auth v1.3.9:
   - Update lib/auth.ts to use betterAuth() instead of NextAuth()
   - Migrate session handling to better-auth patterns
   - Update all import statements
   - Maintain existing OAuth providers
   - Keep current session management logic
   ```
4. Review Cascade's proposed changes before applying
5. Test authentication flow after refactoring

### Flow Collaboration for Feature Development

**Prompt:** "Show me how to use Windsurf Flow to coordinate with my team on building a real-time notification system."

Claude will explain:
1. Create Flow session (Cmd/Ctrl+Shift+F)
2. Define feature scope with Cascade:
   ```
   Implement real-time notifications using Supabase Realtime:
   - Database schema: notifications table with RLS
   - Server-side: Supabase client setup
   - Hooks: useNotifications with real-time subscription
   - UI: NotificationBell component
   - Follow patterns in /lib/supabase and /components/ui
   ```
3. Cascade generates coordinated changes across multiple files
4. Team members can review and collaborate in Flow session
5. Apply changes with atomic commits

### Context-Aware Code Navigation

**Prompt:** "Help me use Cascade to understand how error handling works across our codebase."

Claude will demonstrate:
1. Select a complex error handling function
2. Right-click → Ask Cascade
3. Use prompt:
   ```
   Explain this error handling pattern and show me:
   1. Where else this pattern is used
   2. All files that import this error handler
   3. How errors propagate to the UI layer
   4. Any inconsistencies in error handling
   ```
4. Cascade provides context-aware analysis with file references
5. Navigate to related code using Cascade's suggestions

### Component Extraction with Cascade

**Prompt:** "Use Cascade to extract a reusable UserProfile component from my dashboard page."

Claude will guide:
1. Select the user profile section in dashboard/page.tsx
2. Open Cascade (Cmd/Ctrl+K)
3. Use extraction prompt:
   ```
   Extract user profile section into reusable component:
   - Create components/user/profile.tsx
   - Add TypeScript props interface
   - Support 'compact' and 'full' variants
   - Move styles to component
   - Update dashboard to import and use new component
   ```
4. Review Cascade's component design
5. Apply changes atomically

## Tips for Best Results

1. **Specific File Context**: When using Cascade, select all related files first (Cmd/Ctrl+Click in sidebar) to provide complete context for multi-file operations.

2. **Structured Prompts**: Format Cascade prompts with numbered steps or bullet points for complex refactorings to get organized, sequential changes.

3. **Reference Existing Patterns**: In prompts, reference specific files or patterns ("Follow patterns in /lib/api") to ensure consistency.

4. **Atomic Operations**: Use Flow sessions for coordinated multi-file changes to maintain codebase integrity.

5. **Verify Before Apply**: Always review Cascade's proposed changes before applying, especially for critical security or authentication code.

6. **Leverage Type Awareness**: Windsurf's deep TypeScript integration helps Cascade understand type dependencies across files - mention "maintain type safety" in prompts.

## Common Workflows

### Complete Feature Implementation
```
"Use Cascade Flow to implement user profile editing:
1. Database: Add Prisma schema for user profiles
2. API: Create tRPC mutations for profile updates
3. Validation: Define Zod schemas
4. UI: Build profile edit form with react-hook-form
5. State: Add optimistic updates
6. Follow our existing patterns in /lib and /components"
```

### Security Audit with Cascade
```
"Run Cascade security audit on authentication flow:
1. Analyze all files in /lib/auth and /app/api/auth
2. Check for OWASP Top 10 vulnerabilities
3. Verify input validation with Zod
4. Review session management security
5. Identify any exposed secrets or tokens
6. Suggest security improvements"
```

### Codebase Modernization
```
"Use Cascade to migrate from React 18 to React 19:
1. Update package.json dependencies
2. Migrate class components to functional components with hooks
3. Replace deprecated lifecycle methods
4. Update ReactDOM.render to createRoot
5. Adopt new React 19 features (useOptimistic, useFormStatus)
6. Update tests for new React Testing Library patterns"
```

### Performance Optimization
```
"Cascade analysis for performance optimization:
1. Identify components causing unnecessary re-renders
2. Suggest React.memo, useCallback, useMemo placements
3. Find expensive operations that could use useTransition
4. Optimize database queries in Server Components
5. Suggest code splitting opportunities
6. Analyze bundle size impact"
```

## Troubleshooting

**Issue:** Cascade makes changes that break type safety
**Solution:** In your prompt, explicitly state "maintain strict TypeScript type safety" and "verify all type definitions are updated." Review changes before applying.

**Issue:** Cascade doesn't understand project-specific patterns
**Solution:** Reference specific files in your prompt: "Follow the API pattern in /lib/api/base.ts" to teach Cascade your conventions.

**Issue:** Flow sessions become too large and slow
**Solution:** Break large features into smaller Flow sessions focused on specific layers (database, API, UI) rather than entire features at once.

**Issue:** Cascade refactorings miss edge cases
**Solution:** After Cascade applies changes, ask: "Review the refactoring for edge cases, error handling, and boundary conditions. Suggest tests to verify correctness."

**Issue:** Team members can't see Flow changes
**Solution:** Ensure Flow session is properly shared (check session permissions) and all team members have latest Windsurf version installed.

## Learn More

- [Windsurf Documentation](https://docs.codeium.com/windsurf)
- [Cascade AI Guide](https://docs.codeium.com/windsurf/cascade)
- [Flow Collaboration Patterns](https://docs.codeium.com/windsurf/flow)
- [Windsurf vs Cursor Comparison](https://codeium.com/compare/windsurf-cursor)
- [AI-Native Development Best Practices](https://docs.codeium.com/windsurf/best-practices)


## Prerequisites

- Windsurf IDE installed
- Active project/codebase
- Git repository (recommended)

## Key Features

- Cascade AI for multi-file context-aware operations
- Flow sessions for team collaboration
- Intelligent code navigation with AI assistance
- Automated refactoring workflows
- Real-time collaborative coding
- Deep TypeScript and project context understanding

## Use Cases

- Multi-file refactoring and migrations
- Team-based feature development
- Codebase understanding and navigation
- Automated code reviews and quality checks

## Examples

### Example 1: Multi-File Authentication Refactoring

```typescript
// Cascade Prompt Example:
// "Refactor authentication to use better-auth v1.3.9 across these files:
//  - lib/auth.ts
//  - app/api/auth/[...auth]/route.ts
//  - components/login-form.tsx
//  Maintain all existing OAuth providers and session logic."

// Before: lib/auth.ts (NextAuth)
import NextAuth from 'next-auth';
import { authOptions } from './options';

export const { handlers, signIn, signOut, auth } = NextAuth(authOptions);

// After: lib/auth.ts (better-auth) - Generated by Cascade
import { betterAuth } from 'better-auth';
import { prismaAdapter } from 'better-auth/adapters/prisma';
import { prisma } from '@/lib/db';

export const auth = betterAuth({
  database: prismaAdapter(prisma, { provider: 'postgresql' }),
  emailAndPassword: { enabled: true },
  socialProviders: {
    github: {
      clientId: process.env.GITHUB_CLIENT_ID!,
      clientSecret: process.env.GITHUB_CLIENT_SECRET!,
    },
    google: {
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
    },
  },
});

export const { signIn, signOut } = auth;
```

### Example 2: Component Extraction with Cascade

```typescript
// Cascade Prompt:
// "Extract user profile section into components/user/profile.tsx
//  with variants support and proper TypeScript types."

// After: components/user/profile.tsx - Generated by Cascade
import type { User } from '@/types/user';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

interface UserProfileProps {
  user: User;
  variant?: 'compact' | 'full';
}

export function UserProfile({ user, variant = 'full' }: UserProfileProps) {
  return (
    <div className="flex items-center gap-4">
      <Avatar className={variant === 'compact' ? 'h-8 w-8' : 'h-16 w-16'}>
        <AvatarImage src={user.avatar} alt={user.name} />
        <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
      </Avatar>
      <div>
        <h3 className={variant === 'compact' ? 'text-sm font-medium' : 'text-lg font-semibold'}>
          {user.name}
        </h3>
        {variant === 'full' && (
          <>
            <p className="text-sm text-muted-foreground">{user.email}</p>
            {user.bio && <p className="mt-2 text-sm">{user.bio}</p>}
          </>
        )}
      </div>
    </div>
  );
}

// Updated dashboard usage:
import { UserProfile } from '@/components/user/profile';

export default function DashboardPage() {
  const { user } = useAuth();
  return (
    <div>
      <UserProfile user={user} variant="full" />
    </div>
  );
}
```

## Troubleshooting

### Cascade doesn't understand project patterns

Reference specific files in prompts: 'Follow patterns in /lib/api/base.ts' to teach Cascade your conventions.

### Type errors after Cascade refactoring

Always include 'maintain strict TypeScript type safety' in prompts and review changes before applying.

### Flow session changes not visible to team

Verify session permissions and ensure all team members have latest Windsurf version.

## Learn More

For additional documentation and resources, visit:

https://docs.codeium.com/windsurf