---
name: mcp-tool-contract-testing
description: "Validate MCP server tools with contract-style tests to catch schema drift, unsafe behavior, and integration regressions early."
---

## Overview

This skill helps AI agents enforce explicit behavior contracts for MCP tools. It prevents accidental schema drift, unsafe edge-case handling, and hidden regressions when tools evolve.

## Compatibility

### Native

- **Claude Code / Claude**: native skill usage via `SKILL.md`.
- **Codex/OpenAI workflows**: compatible with Agent Skills-style `SKILL.md` content as reusable workflow instructions.

### Manual Adaptation

- **OpenClaw, Cursor, Windsurf, Gemini, and similar agents**: use the same skill content as a reusable prompt/workflow file when native skill import is unavailable.

## Prerequisites

- Contract definitions for high-value tools
- Stable test inputs and expected outputs
- Regression thresholds for release decisions

## What This Skill Delivers

- Contract catalog for each tool endpoint
- Validation suite for payload and response guarantees
- Safety/negative tests for malformed and adversarial inputs
- Regression summary for release gating

## How to Use This Skill

1. Define mandatory response fields and allowed ranges.
2. Build positive and negative test vectors.
3. Execute against baseline and candidate builds.
4. Compare behavior and schema diffs.
5. Block release when contract-critical checks fail.

## Troubleshooting

**Issue:** Tool output changes break downstream clients  
**Fix:** Add strict backward-compatibility contract checks for public fields.

**Issue:** Tests pass but runtime still fails on edge cases  
**Fix:** Add adversarial input suites and timeout/error propagation checks.

**Issue:** Frequent false positives in test suite  
**Fix:** Split deterministic contract checks from heuristic quality checks.

## Knowledge Freshness

Treat tooling details as time-sensitive. Re-validate APIs, limits, pricing, auth models, and deployment flags immediately before implementation. If docs conflict with prior memory, follow current official docs and release notes.

## Retrieval Sources

- https://modelcontextprotocol.io/specification/2025-06-18/

## Output Contract

1. Return a concrete plan with implementation order.
2. Provide production-ready commands/config/code snippets (not placeholders).
3. Include explicit assumptions and unresolved risks.
4. Include a verification checklist with pass/fail criteria.

## Quality Gates

- All commands are copy/paste ready.
- Security-sensitive steps call out secret handling and least privilege.
- Version-sensitive guidance cites current docs used.
- Rollback path is included for risky changes.
- Final output includes quick validation commands/tests.
