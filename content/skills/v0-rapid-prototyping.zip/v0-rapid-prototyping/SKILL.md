---
name: v0-rapid-prototyping
description: Build production-ready React components and full pages in minutes using V0.dev AI with shadcn/ui, TailwindCSS v4, and Next.js 15 integration.
---

# V0 Rapid UI Prototyping Workflow Skill

## What This Skill Enables

Claude can generate production-ready React components and complete page layouts using V0.dev patterns - Vercel's breakthrough AI UI generator that has transformed frontend development in 2025. This skill enables instant component creation with shadcn/ui integration, TailwindCSS v4 styling, full TypeScript support, and seamless Next.js 15 App Router compatibility.

## Prerequisites

**Required:**
- Next.js 15+ project (App Router)
- TailwindCSS v4.1+ configured
- shadcn/ui components installed
- Node.js 18+

**What Claude handles automatically:**
- Generating React 19 components with proper TypeScript types
- Applying TailwindCSS v4 styling with CSS variables
- Integrating shadcn/ui components
- Creating responsive, mobile-first layouts
- Adding framer-motion animations
- Implementing accessibility (WCAG 2.2 Level AA)
- Server/Client component distinction

## How to Use This Skill

### Component Generation from Description

**Prompt:** "Create a pricing table component with 3 tiers (Basic, Pro, Enterprise). Include monthly/annual toggle, feature lists with checkmarks, and prominent CTA buttons. Use shadcn/ui Card and Button components."

Claude will:
1. Generate TypeScript component with proper types
2. Use shadcn/ui primitives (Card, Button, Switch)
3. Apply TailwindCSS v4 utility classes
4. Implement state management with useState
5. Add responsive grid layout
6. Include accessibility attributes (ARIA labels)
7. Add smooth transitions with CSS

### Dashboard Layout Creation

**Prompt:** "Build an analytics dashboard layout with sidebar navigation, header with search and notifications, stat cards showing KPIs, revenue chart using Recharts, and recent activity table. Make it fully responsive."

Claude will:
1. Create Server Component for static shell
2. Add Client Components for interactive elements
3. Implement responsive sidebar (mobile drawer)
4. Generate stat cards with icons from lucide-react
5. Integrate Recharts with proper TypeScript types
6. Add loading states with Suspense boundaries
7. Include dark mode support via next-themes

### Form Generation with Validation

**Prompt:** "Create a user registration form with email, password, confirm password, and terms acceptance. Use react-hook-form with Zod validation. Show validation errors inline and disable submit until valid."

Claude will:
1. Generate form with shadcn/ui Form components
2. Define Zod schema with comprehensive validation
3. Integrate react-hook-form with zodResolver
4. Add password strength indicator
5. Implement real-time validation feedback
6. Create accessible error messages
7. Add loading state during submission

### Landing Page Section

**Prompt:** "Design a hero section with gradient background, animated headline text, two CTA buttons, and three feature highlights below. Include subtle animations on scroll using framer-motion."

Claude will:
1. Create responsive hero layout
2. Add gradient backgrounds with TailwindCSS
3. Implement text animations with framer-motion
4. Add button hover effects
5. Create feature cards with icons
6. Implement scroll-triggered animations
7. Optimize for Core Web Vitals

## Tips for Best Results

1. **Be Specific About Components**: Mention exact shadcn/ui components you want (Card, Button, Dialog, etc.) for consistent design system usage.

2. **Request Mobile-First**: Always specify "mobile-first responsive design" to ensure proper breakpoints and touch-friendly interactions.

3. **Accessibility First**: Ask for WCAG 2.2 Level AA compliance to get proper semantic HTML, ARIA labels, and keyboard navigation.

4. **Server vs Client**: Clarify if components need interactivity (Client Component with 'use client') or can be static (Server Component).

5. **Animation Budgets**: Request "performant animations" to get GPU-accelerated framer-motion transitions instead of heavy JavaScript.

6. **Dark Mode**: Specify "with dark mode support" to get proper color variable usage compatible with next-themes.

## Common Workflows

### Complete Page Generation
```
"Create a complete product details page with:
1. Image gallery with thumbnails (Client Component)
2. Product info section (title, price, description)
3. Add to cart button with quantity selector
4. Reviews section with star ratings
5. Related products carousel
6. Mobile-responsive layout with good UX
7. Loading states and error handling"
```

### Component Library Starter
```
"Generate a set of reusable UI components:
1. CustomButton with variants (primary, secondary, outline, ghost)
2. CustomCard with header, content, footer slots
3. CustomInput with label, error message, help text
4. CustomSelect with search and multi-select
5. All components with TypeScript props, accessibility, and Storybook-ready"
```

### Data Visualization Dashboard
```
"Build a data visualization dashboard component:
1. KPI summary cards at top (Revenue, Users, Conversion)
2. Line chart for 30-day trends using Recharts
3. Bar chart for category breakdown
4. Pie chart for traffic sources
5. Data table with sorting and filtering
6. Export to CSV functionality
7. Responsive grid that stacks on mobile"
```

### Authentication UI Flow
```
"Create a complete authentication flow:
1. Login page with email/password and OAuth buttons
2. Registration page with form validation
3. Forgot password page with email input
4. Email verification pending page
5. Password reset page
6. All pages with consistent styling using shadcn/ui
7. Loading states and error handling"
```

## Troubleshooting

**Issue:** Generated components don't match my design system colors
**Solution:** Ask Claude to use CSS variables from globals.css (--primary, --secondary, etc.) instead of hardcoded color values. Specify "use our existing design tokens."

**Issue:** Components are not responsive on mobile
**Solution:** Request "mobile-first responsive design with specific breakpoints: sm (640px), md (768px), lg (1024px)" and ask for preview at each breakpoint.

**Issue:** Too many client components affecting performance
**Solution:** Ask Claude to "identify which components can be Server Components and only use 'use client' for interactive elements like forms, buttons with onClick."

**Issue:** Animations cause layout shift (CLS)
**Solution:** Request "animations that don't affect layout, using transform and opacity only" to maintain good Core Web Vitals scores.

**Issue:** TypeScript errors with component props
**Solution:** Ask Claude to "define explicit TypeScript interfaces for all component props with JSDoc comments" for better type safety.

## Learn More

- [V0.dev Documentation](https://v0.dev/docs)
- [shadcn/ui Components](https://ui.shadcn.com/)
- [TailwindCSS v4 Guide](https://tailwindcss.com/docs)
- [Next.js 15 App Router](https://nextjs.org/docs/app)
- [React 19 Documentation](https://react.dev/)


## Prerequisites

- Next.js 15+
- React 19+
- TailwindCSS v4.1+
- shadcn/ui components

## Key Features

- Instant React component generation with V0 patterns
- shadcn/ui integration with full type safety
- TailwindCSS v4 styling with CSS variables
- Responsive mobile-first layouts
- framer-motion animations
- WCAG 2.2 Level AA accessibility

## Use Cases

- Rapid prototyping of UI designs
- Building production-ready components
- Creating landing pages and marketing sites
- Dashboard and admin panel development

## Examples

### Example 1: Pricing Table Component

```typescript
'use client';

import { useState } from 'react';
import { Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';

interface PricingTier {
  name: string;
  price: { monthly: number; annual: number };
  features: string[];
  cta: string;
  popular?: boolean;
}

const tiers: PricingTier[] = [
  {
    name: 'Basic',
    price: { monthly: 9, annual: 90 },
    features: ['5 projects', '1GB storage', 'Email support'],
    cta: 'Get Started',
  },
  {
    name: 'Pro',
    price: { monthly: 29, annual: 290 },
    features: ['Unlimited projects', '10GB storage', 'Priority support', 'Advanced analytics'],
    cta: 'Start Free Trial',
    popular: true,
  },
  {
    name: 'Enterprise',
    price: { monthly: 99, annual: 990 },
    features: ['Unlimited everything', '100GB storage', '24/7 phone support', 'Custom integrations', 'SLA'],
    cta: 'Contact Sales',
  },
];

export function PricingTable() {
  const [isAnnual, setIsAnnual] = useState(false);

  return (
    <div className="py-12">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">Simple, transparent pricing</h2>
          <div className="mt-6 flex items-center justify-center gap-3">
            <span className={!isAnnual ? 'font-semibold' : 'text-muted-foreground'}>Monthly</span>
            <Switch checked={isAnnual} onCheckedChange={setIsAnnual} />
            <span className={isAnnual ? 'font-semibold' : 'text-muted-foreground'}>
              Annual <span className="text-sm text-primary">(Save 20%)</span>
            </span>
          </div>
        </div>

        <div className="mt-12 grid gap-8 lg:grid-cols-3">
          {tiers.map((tier) => (
            <Card key={tier.name} className={tier.popular ? 'border-primary shadow-lg' : ''}>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  {tier.name}
                  {tier.popular && (
                    <span className="rounded-full bg-primary px-3 py-1 text-xs text-primary-foreground">
                      Popular
                    </span>
                  )}
                </CardTitle>
                <CardDescription>
                  <div className="mt-4 flex items-baseline">
                    <span className="text-4xl font-bold">
                      ${isAnnual ? tier.price.annual / 12 : tier.price.monthly}
                    </span>
                    <span className="ml-1 text-muted-foreground">/month</span>
                  </div>
                  {isAnnual && (
                    <p className="mt-1 text-sm">Billed annually (${tier.price.annual}/year)</p>
                  )}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {tier.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-primary" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter>
                <Button className="w-full" variant={tier.popular ? 'default' : 'outline'}>
                  {tier.cta}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
```

### Example 2: Registration Form with Validation

```typescript
'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Loader2 } from 'lucide-react';

const formSchema = z.object({
  email: z.string().email({ message: 'Please enter a valid email address' }),
  password: z
    .string()
    .min(8, { message: 'Password must be at least 8 characters' })
    .regex(/[A-Z]/, { message: 'Password must contain at least one uppercase letter' })
    .regex(/[0-9]/, { message: 'Password must contain at least one number' }),
  confirmPassword: z.string(),
  acceptTerms: z.boolean().refine((val) => val === true, {
    message: 'You must accept the terms and conditions',
  }),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ['confirmPassword'],
});

type FormValues = z.infer<typeof formSchema>;

export function RegistrationForm() {
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      email: '',
      password: '',
      confirmPassword: '',
      acceptTerms: false,
    },
  });

  const onSubmit = async (data: FormValues) => {
    setIsSubmitting(true);
    try {
      // Submit form
      await new Promise((resolve) => setTimeout(resolve, 2000));
      console.log(data);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Email</FormLabel>
              <FormControl>
                <Input type="email" placeholder="you@example.com" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="password"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Password</FormLabel>
              <FormControl>
                <Input type="password" placeholder="••••••••" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="confirmPassword"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Confirm Password</FormLabel>
              <FormControl>
                <Input type="password" placeholder="••••••••" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="acceptTerms"
          render={({ field }) => (
            <FormItem className="flex flex-row items-start space-x-3 space-y-0">
              <FormControl>
                <Checkbox checked={field.value} onCheckedChange={field.onChange} />
              </FormControl>
              <div className="space-y-1 leading-none">
                <FormLabel>I accept the terms and conditions</FormLabel>
                <FormMessage />
              </div>
            </FormItem>
          )}
        />

        <Button type="submit" className="w-full" disabled={isSubmitting}>
          {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Create Account
        </Button>
      </form>
    </Form>
  );
}
```

## Troubleshooting

### Missing shadcn/ui components

Run 'npx shadcn-ui@latest add [component-name]' to install required components.

### TypeScript errors with component props

Ensure all shadcn/ui components are properly typed. Update to latest versions.

### Styling conflicts with TailwindCSS

Verify TailwindCSS v4 is configured correctly with CSS variables in globals.css.

## Learn More

For additional documentation and resources, visit:

https://v0.dev/docs