---
name: codex-plugin-creator-capability-pack
description: "Expert Codex plugin capability pack for safe plugin scaffolding, manifest quality, MCP integration, and maintainable distribution."
---

## Knowledge Freshness

This capability pack is pinned to documentation verified on **2026-04-11**.

## Retrieval Sources

- https://github.com/openai/codex
- https://github.com/modelcontextprotocol
- https://spec.modelcontextprotocol.io/specification/

## Core Workflow

1. Define plugin scope, trust boundaries, and runtime dependencies.
2. Build manifest with minimum required capabilities only.
3. Validate tool behavior and failure paths with smoke tests.
4. Add observability and troubleshooting hooks.
5. Publish with maintenance and compatibility policy.

## Overview

This skill helps agents build practical plugins that stay secure and maintainable instead of becoming one-off brittle integrations.

## Capability Scope

- Plugin architecture and capability boundaries
- Manifest quality and permission minimization
- MCP tool interoperability guidance
- Error handling and observability setup
- Release governance and compatibility notes

## Compatibility

### Native

- **Claude Code / Claude**: native skill usage via `SKILL.md`.
- **Codex/OpenAI workflows**: compatible with Agent Skills-style `SKILL.md` content as reusable workflow instructions.

### Manual Adaptation

- **OpenClaw, Cursor, Windsurf, Gemini, and similar agents**: use the same skill content as a reusable prompt/workflow file when native skill import is unavailable.

## Production Rules

- Minimize plugin permissions and document each permission reason.
- Validate tool contracts against strict schema expectations.
- Keep plugin error handling explicit and observable.
- Ship updates with backward-compatibility notes when behavior changes.

## Troubleshooting

**Issue:** Plugin has excessive privilege scope  
**Fix:** reduce manifest permissions to explicit operational minimum.

**Issue:** Tool calls are inconsistent across clients  
**Fix:** enforce contract tests against expected schema/shape.

**Issue:** Plugin errors are hard to diagnose  
**Fix:** add request IDs, structured logs, and clear failure categories.

## Output Contract

1. Plugin plan with trust boundaries.
2. Manifest with justification per permission.
3. Validation and smoke-test protocol.
4. Maintenance and deprecation plan.
