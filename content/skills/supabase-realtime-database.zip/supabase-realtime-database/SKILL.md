---
name: supabase-realtime-database
description: Build full-stack applications with Supabase Postgres, real-time subscriptions, Edge Functions, and pgvector AI integration for 4M+ developers.
---

# Supabase Realtime Database Builder Skill

## What This Skill Enables

Claude can build complete backend systems using Supabase, the open-source Firebase alternative that raised $100M at $5B valuation in October 2025. With 4M+ developers and enterprise-scale Multigres features launching, Supabase provides PostgreSQL database, real-time subscriptions, authentication, storage, and Edge Functions - all with automatic APIs and pgvector for AI embeddings.

## Prerequisites

**Required:**
- Claude Pro subscription or Claude Code CLI
- Supabase account (free tier available)
- Node.js 18+ for client libraries
- Basic SQL and JavaScript knowledge

**What Claude handles automatically:**
- Setting up Supabase project and database schema
- Creating Row Level Security (RLS) policies
- Generating TypeScript types from database
- Implementing real-time subscriptions
- Configuring authentication with multiple providers
- Building Edge Functions with Deno
- Setting up Storage buckets with access control
- Integrating pgvector for AI embeddings

## How to Use This Skill

### Initialize Supabase Project

**Prompt:** "Set up a Supabase project for a task management app with users, projects, tasks tables. Include RLS policies and TypeScript types."

Claude will:
1. Create database schema with foreign keys
2. Set up RLS policies for multi-tenant data
3. Generate migration files
4. Create TypeScript types with supabase gen types
5. Initialize Supabase client in application
6. Add authentication flow
7. Configure authorization rules

### Real-Time Collaboration

**Prompt:** "Build real-time chat functionality where users see messages instantly when posted. Include typing indicators and online presence."

Claude will:
1. Create messages table with indexes
2. Set up real-time subscription channel
3. Implement message broadcasting
4. Add presence tracking
5. Show typing indicator
6. Handle connection state
7. Optimize with message batching

### AI Integration with pgvector

**Prompt:** "Create a semantic search system using pgvector. Store document embeddings from OpenAI and enable similarity search with cosine distance."

Claude will:
1. Enable pgvector extension
2. Create table with vector column
3. Generate embeddings with OpenAI
4. Store vectors in Supabase
5. Implement similarity search RPC
6. Add HNSW index for performance
7. Create semantic search API

### Edge Functions for Business Logic

**Prompt:** "Build Edge Functions that: send welcome emails on signup, process webhook from Stripe, and run nightly data aggregation job."

Claude will:
1. Create Deno Edge Functions
2. Set up function triggers (database, HTTP, cron)
3. Implement email sending with Resend
4. Add Stripe webhook validation
5. Create scheduled job
6. Include error handling and logging
7. Deploy with supabase functions deploy

## Tips for Best Results

1. **RLS is Critical**: Always implement Row Level Security policies. Request policies that match your access patterns (user owns data, team members can access, public read).

2. **Type Generation**: Use `supabase gen types typescript` to generate TypeScript types. This ensures client code matches database schema.

3. **Real-Time Channels**: Supabase real-time has different channel types (postgres_changes, broadcast, presence). Specify which you need based on use case.

4. **Edge Functions with Deno**: Supabase uses Deno for Edge Functions. Request Deno-compatible code (no Node.js-specific APIs).

5. **Storage Access Control**: Storage buckets can be public or private. Request appropriate RLS policies for file access.

6. **Connection Pooling**: For serverless deployments, use Supabase connection pooling to avoid exceeding connection limits.

## Common Workflows

### Complete SaaS Backend
```
"Build a SaaS backend with Supabase:
1. Authentication with email, Google, GitHub OAuth
2. Organizations and team member management
3. Role-based access control (owner, admin, member)
4. Real-time activity feed
5. File uploads to Storage with access control
6. Billing integration with Stripe webhooks
7. Edge Functions for business logic
8. pgvector for AI-powered search"
```

### Social Media Platform
```
"Create social media backend:
1. User profiles with avatars in Storage
2. Posts with likes, comments, shares
3. Real-time notifications
4. Follow/unfollow relationships
5. Feed algorithm with RLS
6. Direct messaging with presence
7. Content moderation Edge Function
8. Full-text search with PostgreSQL"
```

### IoT Data Collection
```
"Build IoT data collection system:
1. Device registration and authentication
2. Time-series data table with partitioning
3. Real-time sensor data streaming
4. Edge Functions for data aggregation
5. Alert system for threshold violations
6. Historical data analytics queries
7. Dashboard real-time updates
8. Export to CSV with Storage"
```

### AI-Powered Knowledge Base
```
"Create knowledge base with AI:
1. Document storage with chunking
2. Generate embeddings with OpenAI
3. Store vectors in pgvector
4. Semantic search with similarity
5. Full-text search fallback
6. Real-time collaborative editing
7. Version history with temporal tables
8. Edge Function for embedding generation"
```

## Troubleshooting

**Issue:** RLS policies blocking valid queries
**Solution:** Check policies with `EXPLAIN` to see applied policies. Use service role key for admin operations. Test policies in SQL editor with `set role authenticated` and `set request.jwt.claim.sub = 'user-id'`.

**Issue:** Real-time subscriptions not receiving updates
**Solution:** Verify table has REPLICA IDENTITY configured. Check RLS policies allow SELECT on rows. Confirm real-time is enabled in Supabase dashboard. Use broadcast channels if PostgreSQL changes insufficient.

**Issue:** Edge Functions timing out
**Solution:** Edge Functions have 60s limit. Optimize database queries. Use connection pooling. Move long-running tasks to background jobs. Check function logs in dashboard.

**Issue:** Type generation failing
**Solution:** Ensure PostgreSQL schema is valid. Check for circular foreign keys. Update Supabase CLI to latest. Use `--local` flag if working with local instance.

**Issue:** Storage upload fails
**Solution:** Check bucket is created and RLS policies allow INSERT. Verify file size within limits. Check MIME type restrictions. Use service role for admin uploads.

**Issue:** Connection pool exhausted
**Solution:** Use Supabase pooler (port 6543 instead of 5432). Implement connection caching. Close connections properly. Consider upgrading plan for more connections.

## Learn More

- [Supabase Official Documentation](https://supabase.com/docs)
- [Supabase JavaScript Client](https://supabase.com/docs/reference/javascript/introduction)
- [Row Level Security Guide](https://supabase.com/docs/guides/auth/row-level-security)
- [Real-Time Subscriptions](https://supabase.com/docs/guides/realtime)
- [Edge Functions Guide](https://supabase.com/docs/guides/functions)
- [pgvector Extension](https://supabase.com/docs/guides/ai/vector-columns)
- [Database Migrations](https://supabase.com/docs/guides/cli/local-development)


## Prerequisites

- Supabase account
- @supabase/supabase-js ^2.38.0
- Node.js 18+
- Supabase CLI for local development

## Key Features

- PostgreSQL with automatic REST and GraphQL APIs
- Real-time subscriptions with websockets
- Built-in authentication and authorization
- pgvector for AI embeddings and similarity search

## Use Cases

- Full-stack web applications
- Real-time collaborative tools
- AI-powered semantic search

## Examples

### Example 1: Initialize Supabase Client

```typescript
import { createClient } from '@supabase/supabase-js';
import { Database } from './types/supabase';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey);

// With authentication
export const createAuthenticatedClient = (accessToken: string) => {
  return createClient<Database>(supabaseUrl, supabaseAnonKey, {
    global: {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    },
  });
};
```

### Example 2: Database Schema with RLS

```sql
-- Create tables
CREATE TABLE profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id),
  username TEXT UNIQUE NOT NULL,
  avatar_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE projects (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  owner_id UUID REFERENCES profiles(id) NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE tasks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id UUID REFERENCES projects(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  completed BOOLEAN DEFAULT FALSE,
  assigned_to UUID REFERENCES profiles(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  USING (auth.uid() = id);

CREATE POLICY "Users can view own projects"
  ON projects FOR SELECT
  USING (auth.uid() = owner_id);

CREATE POLICY "Users can create projects"
  ON projects FOR INSERT
  WITH CHECK (auth.uid() = owner_id);

CREATE POLICY "Users can view tasks in own projects"
  ON tasks FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM projects
      WHERE projects.id = tasks.project_id
      AND projects.owner_id = auth.uid()
    )
  );
```

### Example 3: Real-Time Subscription

```typescript
import { useEffect, useState } from 'react';
import { supabase } from './supabase';
import { Database } from './types/supabase';

type Task = Database['public']['Tables']['tasks']['Row'];

export function useTasks(projectId: string) {
  const [tasks, setTasks] = useState<Task[]>([]);

  useEffect(() => {
    // Fetch initial data
    const fetchTasks = async () => {
      const { data } = await supabase
        .from('tasks')
        .select('*')
        .eq('project_id', projectId)
        .order('created_at', { ascending: false });
      
      if (data) setTasks(data);
    };

    fetchTasks();

    // Subscribe to real-time changes
    const channel = supabase
      .channel(`tasks:${projectId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'tasks',
          filter: `project_id=eq.${projectId}`,
        },
        (payload) => {
          if (payload.eventType === 'INSERT') {
            setTasks((current) => [payload.new as Task, ...current]);
          } else if (payload.eventType === 'UPDATE') {
            setTasks((current) =>
              current.map((task) =>
                task.id === payload.new.id ? (payload.new as Task) : task
              )
            );
          } else if (payload.eventType === 'DELETE') {
            setTasks((current) =>
              current.filter((task) => task.id !== payload.old.id)
            );
          }
        }
      )
      .subscribe();

    return () => {
      channel.unsubscribe();
    };
  }, [projectId]);

  return tasks;
}
```

### Example 4: Edge Function Example

```typescript
// supabase/functions/send-welcome-email/index.ts
import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

serve(async (req) => {
  try {
    const { record } = await req.json();
    const userId = record.id;

    // Get user email
    const { data: profile } = await supabase
      .from('profiles')
      .select('email')
      .eq('id', userId)
      .single();

    if (!profile) {
      throw new Error('Profile not found');
    }

    // Send email (integrate with Resend, SendGrid, etc.)
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${Deno.env.get('RESEND_API_KEY')}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: 'welcome@yourapp.com',
        to: profile.email,
        subject: 'Welcome to YourApp!',
        html: '<h1>Welcome!</h1><p>Thanks for signing up.</p>',
      }),
    });

    return new Response(JSON.stringify({ success: true }), {
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
});
```

## Troubleshooting

### RLS policies blocking queries

Test policies with service role key first. Check policy using EXPLAIN in SQL editor. Verify auth.uid() returns expected user ID.

### Real-time not working

Enable real-time in table settings. Check RLS allows SELECT. Verify REPLICA IDENTITY is FULL. Use broadcast channel if needed.

### Edge Function deployment fails

Check Deno compatibility of imports. Verify environment variables set. Check function logs in dashboard for errors.

## Learn More

For additional documentation and resources, visit:

https://supabase.com/docs