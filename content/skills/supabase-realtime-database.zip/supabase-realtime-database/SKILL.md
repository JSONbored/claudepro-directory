---
name: supabase-realtime-database
description: "Build full-stack applications with Supabase Postgres, real-time subscriptions, Edge Functions, and pgvector AI integration for 4M+ developers."
---

Build full-stack applications with Supabase Postgres, real-time subscriptions, Edge Functions, and pgvector AI integration for 4M+ developers. Create complete backend systems using Supabase - the open-source Firebase alternative with PostgreSQL database, real-time subscriptions via WebSockets (postgres_changes, broadcast, presence), built-in authentication with multiple providers, file storage with access control, and Edge Functions with Deno for custom business logic. Includes automatic REST and GraphQL APIs, Row Level Security (RLS) policies, TypeScript type generation, connection pooling, and pgvector for AI embeddings and similarity search.

## Content

# Supabase Realtime Database Builder Skill

## What This Skill Enables

Claude can build complete backend systems using Supabase, the open-source Firebase alternative that raised $100M at $5B valuation in October 2025. With 4M+ developers and enterprise-scale Multigres features launching, Supabase provides PostgreSQL database, real-time subscriptions, authentication, storage, and Edge Functions - all with automatic APIs and pgvector for AI embeddings.

## Compatibility

### Native

- **Claude Code / Claude**: native skill usage via `SKILL.md`.
- **Codex/OpenAI workflows**: compatible with Agent Skills-style `SKILL.md` content as reusable workflow instructions.

### Manual Adaptation

- **OpenClaw, Cursor, Windsurf, Gemini, and similar agents**: use the same skill content as a reusable prompt/workflow file when native skill import is unavailable.


## Prerequisites

**Required:**
- Claude Pro subscription or Claude Code CLI
- Supabase account (free tier available)
- Node.js 18+ for client libraries
- Basic SQL and JavaScript knowledge

**What Claude handles automatically:**
- Setting up Supabase project and database schema
- Creating Row Level Security (RLS) policies
- Generating TypeScript types from database
- Implementing real-time subscriptions
- Configuring authentication with multiple providers
- Building Edge Functions with Deno
- Setting up Storage buckets with access control
- Integrating pgvector for AI embeddings

## How to Use This Skill

### Initialize Supabase Project

**Prompt:** "Set up a Supabase project for a task management app with users, projects, tasks tables. Include RLS policies and TypeScript types."

Claude will:
1. Create database schema with foreign keys
2. Set up RLS policies for multi-tenant data
3. Generate migration files
4. Create TypeScript types with supabase gen types
5. Initialize Supabase client in application
6. Add authentication flow
7. Configure authorization rules

### Real-Time Collaboration

**Prompt:** "Build real-time chat functionality where users see messages instantly when posted. Include typing indicators and online presence."

Claude will:
1. Create messages table with indexes
2. Set up real-time subscription channel
3. Implement message broadcasting
4. Add presence tracking
5. Show typing indicator
6. Handle connection state
7. Optimize with message batching

### AI Integration with pgvector

**Prompt:** "Create a semantic search system using pgvector. Store document embeddings from OpenAI and enable similarity search with cosine distance."

Claude will:
1. Enable pgvector extension
2. Create table with vector column
3. Generate embeddings with OpenAI
4. Store vectors in Supabase
5. Implement similarity search RPC
6. Add HNSW index for performance
7. Create semantic search API

### Edge Functions for Business Logic

**Prompt:** "Build Edge Functions that: send welcome emails on signup, process webhook from Stripe, and run nightly data aggregation job."

Claude will:
1. Create Deno Edge Functions
2. Set up function triggers (database, HTTP, cron)
3. Implement email sending with Resend
4. Add Stripe webhook validation
5. Create scheduled job
6. Include error handling and logging
7. Deploy with supabase functions deploy

## Tips for Best Results

1. **RLS is Critical**: Always implement Row Level Security policies. Request policies that match your access patterns (user owns data, team members can access, public read).

2. **Type Generation**: Use `supabase gen types typescript` to generate TypeScript types. This ensures client code matches database schema.

3. **Real-Time Channels**: Supabase real-time has different channel types (postgres_changes, broadcast, presence). Specify which you need based on use case.

4. **Edge Functions with Deno**: Supabase uses Deno for Edge Functions. Request Deno-compatible code (no Node.js-specific APIs).

5. **Storage Access Control**: Storage buckets can be public or private. Request appropriate RLS policies for file access.

6. **Connection Pooling**: For serverless deployments, use Supabase connection pooling to avoid exceeding connection limits.

## Common Workflows

### Complete SaaS Backend
```
"Build a SaaS backend with Supabase:
1. Authentication with email, Google, GitHub OAuth
2. Organizations and team member management
3. Role-based access control (owner, admin, member)
4. Real-time activity feed
5. File uploads to Storage with access control
6. Billing integration with Stripe webhooks
7. Edge Functions for business logic
8. pgvector for AI-powered search"
```

### Social Media Platform
```
"Create social media backend:
1. User profiles with avatars in Storage
2. Posts with likes, comments, shares
3. Real-time notifications
4. Follow/unfollow relationships
5. Feed algorithm with RLS
6. Direct messaging with presence
7. Content moderation Edge Function
8. Full-text search with PostgreSQL"
```

### IoT Data Collection
```
"Build IoT data collection system:
1. Device registration and authentication
2. Time-series data table with partitioning
3. Real-time sensor data streaming
4. Edge Functions for data aggregation
5. Alert system for threshold violations
6. Historical data analytics queries
7. Dashboard real-time updates
8. Export to CSV with Storage"
```

### AI-Powered Knowledge Base
```
"Create knowledge base with AI:
1. Document storage with chunking
2. Generate embeddings with OpenAI
3. Store vectors in pgvector
4. Semantic search with similarity
5. Full-text search fallback
6. Real-time collaborative editing
7. Version history with temporal tables
8. Edge Function for embedding generation"
```

## Troubleshooting

**Issue:** RLS policies blocking valid queries
**Solution:** Check policies with `EXPLAIN` to see applied policies. Use service role key for admin operations. Test policies in SQL editor with `set role authenticated` and `set request.jwt.claim.sub = 'user-id'`.

**Issue:** Real-time subscriptions not receiving updates
**Solution:** Verify table has REPLICA IDENTITY configured. Check RLS policies allow SELECT on rows. Confirm real-time is enabled in Supabase dashboard. Use broadcast channels if PostgreSQL changes insufficient.

**Issue:** Edge Functions timing out
**Solution:** Edge Functions have 60s limit. Optimize database queries. Use connection pooling. Move long-running tasks to background jobs. Check function logs in dashboard.

**Issue:** Type generation failing
**Solution:** Ensure PostgreSQL schema is valid. Check for circular foreign keys. Update Supabase CLI to latest. Use `--local` flag if working with local instance.

**Issue:** Storage upload fails
**Solution:** Check bucket is created and RLS policies allow INSERT. Verify file size within limits. Check MIME type restrictions. Use service role for admin uploads.

**Issue:** Connection pool exhausted
**Solution:** Use Supabase pooler (port 6543 instead of 5432). Implement connection caching. Close connections properly. Consider upgrading plan for more connections.

## Learn More

- [Supabase Official Documentation](https://supabase.com/docs)
- [Supabase JavaScript Client](https://supabase.com/docs/reference/javascript/introduction)
- [Row Level Security Guide](https://supabase.com/docs/guides/auth/row-level-security)
- [Real-Time Subscriptions](https://supabase.com/docs/guides/realtime)
- [Edge Functions Guide](https://supabase.com/docs/guides/functions)
- [pgvector Extension](https://supabase.com/docs/guides/ai/vector-columns)
- [Database Migrations](https://supabase.com/docs/guides/cli/local-development)

## Features

- PostgreSQL with automatic REST and GraphQL APIs via PostgREST and pg_graphql
- Real-time subscriptions with WebSockets (postgres_changes, broadcast, presence)
- Built-in authentication and authorization with email, OAuth, phone, passwordless, SSO
- pgvector for AI embeddings and similarity search with HNSW and IVFFlat indexes
- Edge Functions with Deno for globally distributed TypeScript serverless functions
- Storage buckets with access control, CDN, image transformations, and resumable uploads
- Row Level Security (RLS) policies for granular data access control
- TypeScript type generation from database schema with supabase gen types

## Use Cases

- Full-stack web applications with real-time collaboration
- Real-time collaborative tools with presence tracking and broadcast messaging
- AI-powered semantic search with pgvector embeddings
- SaaS backends with multi-tenant data isolation using RLS
- Social media platforms with real-time notifications and activity feeds
- IoT data collection systems with time-series data and real-time streaming
