---
name: github-actions-secure-cicd-capability-pack
description: "Expert GitHub Actions capability skill for secure workflow architecture, token minimization, supply-chain controls, and CI reliability."
---

## Knowledge Freshness

This capability pack is pinned to documentation verified on **2026-04-10**.
When upstream docs change, refresh endpoint contracts, examples, and constraints before using this skill for production changes.

## Retrieval Sources

- https://docs.github.com/actions
- https://docs.github.com/actions/security-for-github-actions/security-guides/automatic-token-authentication
- https://docs.github.com/actions/learn-github-actions/reusing-workflows

Always prefer direct retrieval from official docs/API references over model memory for limits, endpoint signatures, and behavior guarantees.

## Core Workflow

1. Confirm target version/runtime and pull latest official docs for the task scope.
2. Build an execution plan with explicit read-only discovery before any mutation.
3. Validate contracts, permissions, and safety constraints before applying changes.
4. Execute with deterministic checkpoints and rollback criteria.
5. Produce a verification report with evidence, caveats, and next actions.

## Overview

This capability pack teaches agents how to build secure and resilient GitHub Actions systems. It focuses on practical controls that reduce compromise risk and operational breakage.

## Capability Scope

- Workflow architecture and trust boundaries
- Token permissions and environment scoping
- Action pinning and supply-chain controls
- Reusable workflow governance
- Build reliability and incident handling

## Compatibility

### Native

- **Claude Code / Claude**: native skill usage via `SKILL.md`.
- **Codex/OpenAI workflows**: compatible with Agent Skills-style `SKILL.md` content as reusable workflow instructions.

### Manual Adaptation

- **OpenClaw, Cursor, Windsurf, Gemini, and similar agents**: use the same skill content as a reusable prompt/workflow file when native skill import is unavailable.

## Production Rules

- Grant minimum workflow permissions by job.
- Pin third-party actions to immutable refs.
- Separate trusted release workflows from untrusted PR execution.
- Capture artifacts/logs for post-failure diagnostics.

## Troubleshooting

**Issue:** CI passes in PRs but fails after merge  
**Fix:** Align PR and main workflow environments and dependency assumptions.

**Issue:** Workflow has excessive token scope  
**Fix:** Reduce permissions per job and isolate privileged steps to protected environments.

**Issue:** Third-party action risk is unclear  
**Fix:** Pin exact versions/SHAs and periodically review upstream security posture.

## Output Contract

1. Provide an implementation plan ordered by risk and dependency.
2. Provide exact production-ready config/commands with no placeholders.
3. Call out secrets, permissions, and least-privilege requirements.
4. Include rollback and recovery guidance for each risky step.

## Validation Checklist

- Verify all referenced docs/versions before applying changes.
- Run smoke checks for core user flow and error paths.
- Confirm observability/logging is enabled for changed components.
- Confirm security controls (auth, rate limits, input validation) still pass.
- Record final known limitations and follow-up actions.
