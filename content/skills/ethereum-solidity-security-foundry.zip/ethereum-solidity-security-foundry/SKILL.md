---
name: ethereum-solidity-security-foundry
description: "Build and harden Ethereum smart contracts with Foundry, invariant testing, and battle-tested OpenZeppelin security patterns."
---

## Overview

This skill gives AI agents a security-first operating model for Ethereum smart contracts. It combines pragmatic architecture guidance with strict testing discipline and deployment safeguards.

## Compatibility

### Native

- **Claude Code / Claude**: native skill usage via `SKILL.md`.
- **Codex/OpenAI workflows**: compatible with Agent Skills-style `SKILL.md` content as reusable workflow instructions.

### Manual Adaptation

- **OpenClaw, Cursor, Windsurf, Gemini, and similar agents**: use the same skill content as a reusable prompt/workflow file when native skill import is unavailable.

## Prerequisites

- Contract requirements and threat boundaries
- Access controls and upgrade policy decisions
- Testnet deployment pipeline

## What This Skill Delivers

- Security-centric contract design review
- Foundry unit, fuzz, and invariant test strategy
- Common exploit class defenses (reentrancy, auth, oracle, rounding, griefing)
- Pre-deploy and post-deploy operational checklist

## How to Use This Skill

1. Define assets, actors, and privileged operations.
2. Build minimal contract surface area with explicit invariants.
3. Implement and test against adversarial cases.
4. Run static/dynamic checks before deployment.
5. Deploy progressively with monitoring and pause controls.

## Troubleshooting

**Issue:** Tests pass but invariants fail under fuzzing  
**Fix:** Revisit state transitions and assumptions around edge-case ordering.

**Issue:** Access control too broad  
**Fix:** Replace role overreach with least-privilege split roles and delayed admin ops.

**Issue:** Upgrades create storage breakage  
**Fix:** Add storage layout checks and upgrade simulation in CI before release.

## Knowledge Freshness

Treat tooling details as time-sensitive. Re-validate APIs, limits, pricing, auth models, and deployment flags immediately before implementation. If docs conflict with prior memory, follow current official docs and release notes.

## Retrieval Sources

- https://ethereum.org/developers/docs/

## Output Contract

1. Return a concrete plan with implementation order.
2. Provide production-ready commands/config/code snippets (not placeholders).
3. Include explicit assumptions and unresolved risks.
4. Include a verification checklist with pass/fail criteria.

## Quality Gates

- All commands are copy/paste ready.
- Security-sensitive steps call out secret handling and least privilege.
- Version-sensitive guidance cites current docs used.
- Rollback path is included for risky changes.
- Final output includes quick validation commands/tests.
