---
name: coderabbit-lite-pr-review-capability-pack
description: "Expert code-review capability pack for deterministic PR audits, risk-ranked findings, and low-noise fix planning without SaaS lock-in."
---

## Knowledge Freshness

This capability pack is pinned to documentation verified on **2026-04-11**.
Refresh references before using this skill for critical production decisions.

## Retrieval Sources

- https://docs.github.com/en/pull-requests
- https://owasp.org/www-project-top-ten/
- https://cheatsheetseries.owasp.org/

## Core Workflow

1. Build threat model from changed files and data boundaries.
2. Classify findings by exploitability and operational impact.
3. Remove low-confidence noise before presenting blockers.
4. Produce minimal, file-scoped patch plan with validation gates.
5. Re-check changed attack surfaces after fixes land.

## Overview

This skill teaches agents to perform fast, low-noise code reviews that mimic senior reviewer behavior: clear severity, concrete evidence, and fix-first recommendations.

## Capability Scope

- PR diff triage and risk scoring
- Security and reliability regression detection
- False-positive suppression rules
- Patch-plan generation with owner mapping
- Post-fix verification guidance

## Compatibility

### Native

- **Claude Code / Claude**: native skill usage via `SKILL.md`.
- **Codex/OpenAI workflows**: compatible with Agent Skills-style `SKILL.md` content as reusable workflow instructions.

### Manual Adaptation

- **OpenClaw, Cursor, Windsurf, Gemini, and similar agents**: use the same skill content as a reusable prompt/workflow file when native skill import is unavailable.

## Production Rules

- Do not block merges on low-confidence findings.
- Require concrete code evidence for every high-severity claim.
- Separate exploitability from style concerns.
- Always include rollback or quick-mitigation options.

## Troubleshooting

**Issue:** Too many low-signal findings  
**Fix:** tighten rule set to changed files and critical paths first.

**Issue:** Security findings lack proof  
**Fix:** require request/response, data-flow, or control-path evidence.

**Issue:** Patch plan is too broad  
**Fix:** break by file ownership and dependency boundary.

## Output Contract

1. Risk-ranked findings with direct evidence.
2. Priority fix plan with smallest safe diff.
3. Validation commands and pass criteria.
4. Remaining residual risks and follow-ups.

## Validation Checklist

- Confirm findings map to changed code.
- Run test/lint/typecheck after patch.
- Re-check auth, input validation, and data handling paths.
- Verify no new critical findings introduced by fixes.
