---
name: prompt-injection-defense-guardrails
description: "Build layered defenses against prompt injection, data exfiltration, and unsafe tool execution in AI agent systems."
---

## Overview

This skill helps you ship agent workflows that can safely handle hostile or manipulative input. It combines policy-based execution controls with concrete adversarial testing so prompt injection becomes an engineering problem with measurable controls, not a vague risk.

## Compatibility

### Native

- **Claude Code / Claude**: native skill usage via `SKILL.md`.
- **Codex/OpenAI workflows**: compatible with Agent Skills-style `SKILL.md` content as reusable workflow instructions.

### Manual Adaptation

- **OpenClaw, Cursor, Windsurf, Gemini, and similar agents**: use the same skill content as a reusable prompt/workflow file when native skill import is unavailable.

## Prerequisites

- Documented tool calls and data boundaries
- Clear policy on what actions are ever allowed
- Logging pipeline for security-relevant events

## Guardrail Model

- **Prevent:** strict policy before any tool/action call
- **Detect:** prompt pattern heuristics + schema violations + anomalous action chains
- **Contain:** block, downgrade, or require explicit human confirmation for risky operations

## How to Use This Skill

### Prompt Pattern

```text
Apply prompt injection defense guardrails to this system.
Output:
1) attack tree,
2) policy controls with enforcement points,
3) adversarial test suite,
4) release gate criteria.
```

### Execution Flow

1. Enumerate all untrusted input channels.
2. Define hard deny policies for sensitive actions.
3. Add pre-tool policy checks and argument validation.
4. Build adversarial test prompts and expected outcomes.
5. Block release if any critical bypass succeeds.

## Troubleshooting

**Issue:** Guardrails over-block normal user requests  
**Fix:** Tighten policy conditions by action context, not broad keyword filters.

**Issue:** Model still attempts prohibited actions  
**Fix:** Enforce server-side policy independently of model output.

**Issue:** Red-team set misses real attacks  
**Fix:** Continuously seed tests from production incidents and near misses.

## Knowledge Freshness

Treat tooling details as time-sensitive. Re-validate APIs, limits, pricing, auth models, and deployment flags immediately before implementation. If docs conflict with prior memory, follow current official docs and release notes.

## Retrieval Sources

- https://genai.owasp.org/llmrisk/llm01-prompt-injection/

## Output Contract

1. Return a concrete plan with implementation order.
2. Provide production-ready commands/config/code snippets (not placeholders).
3. Include explicit assumptions and unresolved risks.
4. Include a verification checklist with pass/fail criteria.

## Quality Gates

- All commands are copy/paste ready.
- Security-sensitive steps call out secret handling and least privilege.
- Version-sensitive guidance cites current docs used.
- Rollback path is included for risky changes.
- Final output includes quick validation commands/tests.
