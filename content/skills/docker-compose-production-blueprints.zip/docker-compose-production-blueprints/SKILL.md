---
name: docker-compose-production-blueprints
description: "Create production-grade Docker Compose stacks with healthchecks, secrets handling, network isolation, and safe rollout patterns."
---

## Overview

This skill provides consistent production patterns for Docker Compose stacks. It helps AI agents avoid common anti-patterns and produce deployment configs that are safer to run and easier to maintain.

## Compatibility

### Native

- **Claude Code / Claude**: native skill usage via `SKILL.md`.
- **Codex/OpenAI workflows**: compatible with Agent Skills-style `SKILL.md` content as reusable workflow instructions.

### Manual Adaptation

- **OpenClaw, Cursor, Windsurf, Gemini, and similar agents**: use the same skill content as a reusable prompt/workflow file when native skill import is unavailable.

## Prerequisites

- Clear service boundaries and ownership
- Persistent data strategy
- Operational SLO targets

## What This Skill Delivers

- Compose architecture with profile-aware services
- Network and privilege minimization guidance
- Healthchecks, restart policy, and dependency sequencing
- Safe change rollout and rollback checklist

## How to Use This Skill

1. Model service topology and stateful dependencies.
2. Define secret strategy and avoid plaintext in repo.
3. Add healthchecks and startup ordering guards.
4. Constrain network exposure and privileges.
5. Validate with restart, failover, and upgrade simulations.

## Troubleshooting

**Issue:** Services start but fail shortly after  
**Fix:** Add robust healthchecks and delay dependent services until healthy.

**Issue:** Compose changes break unrelated services  
**Fix:** Use profiles and explicit dependency contracts to scope blast radius.

**Issue:** Secrets leak into logs or env dumps  
**Fix:** Move sensitive values to secrets manager or runtime-injected env.

## Knowledge Freshness

Treat tooling details as time-sensitive. Re-validate APIs, limits, pricing, auth models, and deployment flags immediately before implementation. If docs conflict with prior memory, follow current official docs and release notes.

## Retrieval Sources

- https://docs.docker.com/compose/

## Output Contract

1. Return a concrete plan with implementation order.
2. Provide production-ready commands/config/code snippets (not placeholders).
3. Include explicit assumptions and unresolved risks.
4. Include a verification checklist with pass/fail criteria.

## Quality Gates

- All commands are copy/paste ready.
- Security-sensitive steps call out secret handling and least privilege.
- Version-sensitive guidance cites current docs used.
- Rollback path is included for risky changes.
- Final output includes quick validation commands/tests.
