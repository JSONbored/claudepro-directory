---
name: ai-search-ranking-content-cluster-strategy
description: "Build SEO-forward content clusters that align with search intent, topical authority, and conversion pathways for AI tooling niches."
---

## Overview

This skill helps AI agents create practical, ranking-oriented content programs. It focuses on intent-driven coverage, robust internal linking, and repeatable publishing operations.

## Compatibility

### Native

- **Claude Code / Claude**: native skill usage via `SKILL.md`.
- **Codex/OpenAI workflows**: compatible with Agent Skills-style `SKILL.md` content as reusable workflow instructions.

### Manual Adaptation

- **OpenClaw, Cursor, Windsurf, Gemini, and similar agents**: use the same skill content as a reusable prompt/workflow file when native skill import is unavailable.

## Prerequisites

- ICP and audience pain points
- Topic boundaries and business relevance
- Publishing capacity estimate

## What This Skill Delivers

- Search intent map by funnel stage
- Cluster architecture and page-level briefs
- Internal link model for authority flow
- Refresh strategy based on performance signals

## How to Use This Skill

1. Build keyword universe from real user problems.
2. Group by intent and business relevance.
3. Design pillar/cluster page architecture.
4. Define internal links and conversion pathways.
5. Publish, measure, and refresh using clear rules.

## Troubleshooting

**Issue:** Traffic grows but conversions stay flat  
**Fix:** Align cluster CTAs and page intent with concrete user next steps.

**Issue:** New pages cannibalize each other  
**Fix:** Tighten intent separation and canonical/internal-link structure.

**Issue:** Rankings plateau  
**Fix:** Expand cluster depth and update aging pages with new evidence/examples.

## Knowledge Freshness

Treat tooling details as time-sensitive. Re-validate APIs, limits, pricing, auth models, and deployment flags immediately before implementation. If docs conflict with prior memory, follow current official docs and release notes.

## Retrieval Sources

- https://developers.google.com/search/docs

## Output Contract

1. Return a concrete plan with implementation order.
2. Provide production-ready commands/config/code snippets (not placeholders).
3. Include explicit assumptions and unresolved risks.
4. Include a verification checklist with pass/fail criteria.

## Quality Gates

- All commands are copy/paste ready.
- Security-sensitive steps call out secret handling and least privilege.
- Version-sensitive guidance cites current docs used.
- Rollback path is included for risky changes.
- Final output includes quick validation commands/tests.
